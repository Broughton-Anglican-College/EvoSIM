import pygame
import sys
import random
import math
import os
import json
from datetime import datetime

#constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1280, 720
FPS = 60

#homescreen parameters
RABBIT_COUNT = 1000
RABBIT_SIZE = 30
RABBIT_FLEE_DISTANCE = 150
RABBIT_SPEED = 2
RABBIT_WANDER_TIME = 60
RABBIT_COLLISION_DISTANCE = RABBIT_SIZE * 1.2
FOX_SIZE = 45 #cursor size for homescreen

#colour schemes for application, accessability features
COLOUR_SCHEMES = {
    "default": {
        "background": (64, 64, 64),
        "text": (255, 255, 255),
        "button": (30, 30, 30),
        "button_hover": (50, 50, 50),
        "border": (80, 80, 80),
        "border_hover": (100, 100, 100),
        "title": (0, 0, 0),
        "rabbit_bg": (255, 255, 255),
        "graph_bg": (30, 30, 30),
        "graph_prey": (0, 255, 0),
        "graph_predator": (255, 0, 0),
        "graph_axis": (200, 200, 200)
    },
    "high_contrast": {
        "background": (0, 0, 0),
        "text": (255, 255, 255),
        "button": (0, 0, 0),
        "button_hover": (50, 50, 50),
        "border": (255, 255, 255),
        "border_hover": (255, 255, 0),
        "title": (255, 255, 0),
        "rabbit_bg": (255, 255, 255),
        "graph_bg": (0, 0, 0),
        "graph_prey": (0, 255, 0),
        "graph_predator": (255, 0, 0),
        "graph_axis": (255, 255, 255)
    },
    "dark_blue": {
        "background": (0, 0, 50),
        "text": (200, 200, 255),
        "button": (0, 0, 80),
        "button_hover": (0, 0, 120),
        "border": (100, 100, 255),
        "border_hover": (150, 150, 255),
        "title": (200, 200, 255),
        "rabbit_bg": (255, 255, 255),
        "graph_bg": (0, 0, 30),
        "graph_prey": (100, 255, 100),
        "graph_predator": (255, 100, 100),
        "graph_axis": (150, 150, 255)
    },
    "light_mode": {
        "background": (240, 240, 240),
        "text": (0, 0, 0),
        "button": (220, 220, 220),
        "button_hover": (200, 200, 200),
        "border": (100, 100, 100),
        "border_hover": (50, 50, 50),
        "title": (0, 0, 0),
        "rabbit_bg": (255, 255, 255),
        "graph_bg": (255, 255, 255),
        "graph_prey": (0, 200, 0),
        "graph_predator": (200, 0, 0),
        "graph_axis": (50, 50, 50)
    }
}


class ColourManager:
    def __init__(self):
        self.current_scheme = "default"
        self.load_settings()
        
    def load_settings(self):
        #attempt to load colour scheme from settings file
        try:
            with open('settings.json', 'r') as f:
                settings = json.load(f)
                #check if loaded scheme exists in available schemes
                if settings.get('colour_scheme') in COLOUR_SCHEMES:
                    self.current_scheme = settings['colour_scheme']
        except (FileNotFoundError, json.JSONDecodeError):
            #fallback to default if file missing or invalid
            self.current_scheme = "default"
            
    def save_settings(self):
        #save current colour scheme to settings file
        with open('settings.json', 'w') as f:
            json.dump({'colour_scheme': self.current_scheme}, f)
            
    def get_colours(self):
        #return colours for current scheme
        return COLOUR_SCHEMES[self.current_scheme]

#create colour manager instance and get colours
colour_manager = ColourManager()
colours = colour_manager.get_colours()

class Rabbit:
    def __init__(self, rabbit_img):
        #initialize rabbit position randomly on screen
        self.x = random.randint(0, SCREEN_WIDTH - RABBIT_SIZE)
        self.y = random.randint(0, SCREEN_HEIGHT - RABBIT_SIZE)
        self.size = RABBIT_SIZE
        self.speed = RABBIT_SPEED
        #random starting direction
        self.direction = random.uniform(0, 2 * math.pi)
        self.wander_timer = random.randint(0, RABBIT_WANDER_TIME)
        self.base_image = rabbit_img
        self.image = rabbit_img
        self.facing_left = False
        self.is_disappearing = False
        self.disappear_timer = 30
        
    def update(self, mouse_pos, rabbits):
        #handle disappearing animation
        if self.is_disappearing:
            self.disappear_timer -= 1
            self.size = max(0, int(RABBIT_SIZE * (self.disappear_timer/30)))
            return
            
        mx, my = mouse_pos
        prev_x = self.x
        
        #check collision with fox
        fox_rect = pygame.Rect(mx - FOX_SIZE//2, my - FOX_SIZE//2, FOX_SIZE, FOX_SIZE)
        rabbit_rect = pygame.Rect(self.x, self.y, self.size, self.size)
        
        if fox_rect.colliderect(rabbit_rect):
            self.is_disappearing = True
            return

        #calculate distance to fox
        dx = self.x + self.size/2 - mx
        dy = self.y + self.size/2 - my
        distance = math.hypot(dx, dy)
        
        #flee from fox if too close
        if distance < RABBIT_FLEE_DISTANCE:
            target_direction = math.atan2(dy, dx)
            angle_diff = (target_direction - self.direction + math.pi) % (2 * math.pi) - math.pi
            self.direction += angle_diff * 0.2
            self.speed = RABBIT_SPEED * 1.5
            self.wander_timer = 0
        else:
            #random wandering behavior
            if self.wander_timer <= 0:
                self.direction += random.uniform(-0.5, 0.5)
                self.wander_timer = RABBIT_WANDER_TIME
                self.speed = RABBIT_SPEED * random.uniform(0.8, 1.2)
            else:
                self.wander_timer -= 1
        
        #move rabbit
        self.x += math.cos(self.direction) * self.speed
        self.y += math.sin(self.direction) * self.speed
            
        #flip sprite based on movement direction
        if self.x < prev_x and not self.facing_left:
            self.facing_left = True
            self.image = pygame.transform.flip(self.base_image, True, False)
        elif self.x > prev_x and self.facing_left:
            self.facing_left = False
            self.image = self.base_image
                
        #avoid collisions with other rabbits
        for other in rabbits:
            if other == self or other.is_disappearing:
                continue
                
            dist = math.hypot(other.x - self.x, other.y - self.y)
            if dist < RABBIT_COLLISION_DISTANCE:
                repel_dir = math.atan2(self.y-other.y, self.x-other.x)
                strength = min(1.5, (RABBIT_COLLISION_DISTANCE - dist)/10)
                angle_diff = (repel_dir - self.direction + math.pi) % (2 * math.pi) - math.pi
                self.direction += angle_diff * 0.3 * strength
                self.speed = RABBIT_SPEED * (1 + strength * 0.5)
        
        #keep rabbit within screen bounds
        if self.x < 0:
            self.x = 0
            self.direction = math.pi - self.direction + random.uniform(-0.2, 0.2)
        elif self.x > SCREEN_WIDTH - self.size:
            self.x = SCREEN_WIDTH - self.size
            self.direction = math.pi - self.direction + random.uniform(-0.2, 0.2)
            
        if self.y < 0:
            self.y = 0
            self.direction = -self.direction + random.uniform(-0.2, 0.2)
        elif self.y > SCREEN_HEIGHT - self.size:
            self.y = SCREEN_HEIGHT - self.size
            self.direction = -self.direction + random.uniform(-0.2, 0.2)
        
        #normalize direction angle
        self.direction %= 2 * math.pi
        
    def draw(self, screen):
        #draw rabbit with fade effect if disappearing
        if self.is_disappearing and self.size > 0:
            img = pygame.transform.flip(self.base_image, self.facing_left, False) if self.facing_left else self.base_image
            img = pygame.transform.scale(img, (self.size, self.size))
            img.set_alpha(int(255 * (self.disappear_timer/30)))
            screen.blit(img, (self.x, self.y))
        elif not self.is_disappearing:
            screen.blit(self.image, (self.x, self.y))

class Button:
    def __init__(self, x, y, width, height, text, font, image_path=None):
        #create button rectangle and initialize properties
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.hovered = False
        self.image = self._load_image(image_path, width, height) if image_path else None
    def _load_image(self, path, width, height):
        #load and scale image for button
        try:
            img = pygame.image.load(path)
            size = min(width, height) - 20
            return pygame.transform.scale(img, (size, size))
        except pygame.error:
            print(f"Could not load image: {path}")
            return None
        
    def draw(self, screen):
        #select colours based on hover state
        colour = colours["button_hover"] if self.hovered else colours["button"]
        border = colours["border_hover"] if self.hovered else colours["border"]
        
        #draw button background and border
        pygame.draw.rect(screen, colour, self.rect, border_radius=15)
        pygame.draw.rect(screen, border, self.rect, width=2, border_radius=15)
        
        #draw image or text in center
        if self.image:
            screen.blit(self.image, self.image.get_rect(center=self.rect.center))
        else:
            text = self.font.render(self.text, True, colours["text"])
            screen.blit(text, text.get_rect(center=self.rect.center))
    def handle_event(self, event):
        #update hover state and check for clicks
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        return event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.hovered

class GameState:
    def __init__(self, screen, background=None):
        #initialize game state with screen and optional background
        self.screen = screen
        self.background = background
        self.buttons = {}
        #create different font sizes for ui elements
        self.title_font = pygame.font.Font(None, 72)
        self.button_font = pygame.font.Font(None, 28)
        self.small_font = pygame.font.Font(None, 22)
        self.init_ui()
        
    def init_ui(self): pass

    def handle_event(self, event):
        #check if any button was clicked and return its name
        for name, button in self.buttons.items():
            if button.handle_event(event):
                return name
        return None
    
    def draw(self):
        #clear screen and draw all buttons
        self.screen.fill(colours["background"])
        for button in self.buttons.values():
            button.draw(self.screen)
            
    def update(self): pass

class HomePage(GameState):
    def __init__(self, screen, background=None):
        #load and scale rabbit image
        self.rabbit_img = pygame.image.load('rabbit.png').convert_alpha()
        self.rabbit_img = pygame.transform.scale(self.rabbit_img, (RABBIT_SIZE, RABBIT_SIZE))
        #load and scale fox image
        self.fox_img = pygame.image.load('fox.png').convert_alpha()
        self.fox_img = pygame.transform.scale(self.fox_img, (FOX_SIZE, FOX_SIZE))
        
        super().__init__(screen, background)
        #create initial rabbits
        self.rabbits = [Rabbit(self.rabbit_img) for _ in range(RABBIT_COUNT)]
        self.init_ui()
        self.fox_facing_left = False
        self.last_mouse_x = SCREEN_WIDTH // 2
    def init_ui(self):
        #set up button dimensions and positioning
        button_width, button_height = 400, 70
        start_y = SCREEN_HEIGHT // 2 - 20
        
        #create main menu buttons
        self.buttons = {
            'new': Button(SCREEN_WIDTH//2 - button_width//2, start_y, 
                         button_width, button_height, "Start New Simulation", self.button_font),
            'load': Button(SCREEN_WIDTH//2 - button_width//2, start_y + button_height + 25,
                         button_width, button_height, "Load Saved Simulation", self.button_font),
            'tutorial': Button(SCREEN_WIDTH//2 - button_width//2, start_y + 2*(button_height + 25),
                             button_width, button_height, "Tutorial", self.button_font),
            'settings': Button(SCREEN_WIDTH - 80, 20, 60, 60, "Settings", 
                             pygame.font.Font(None, 18))
        }
        self.title_font = pygame.font.Font(None, 120)
    def update(self):
        #track mouse movement for fox direction
        mouse_pos = pygame.mouse.get_pos()
        current_mouse_x = mouse_pos[0]
        
        #update fox facing direction based on mouse movement
        if current_mouse_x < self.last_mouse_x:
            self.fox_facing_left = True
        elif current_mouse_x > self.last_mouse_x:
            self.fox_facing_left = False
        self.last_mouse_x = current_mouse_x
        
        #remove fully disappeared rabbits
        self.rabbits = [r for r in self.rabbits if not r.is_disappearing or r.disappear_timer > 0]
            
        #update each rabbit
        for rabbit in self.rabbits:
            rabbit.update(mouse_pos, self.rabbits)
            
            #check collision with buttons and push rabbits away
            for button in self.buttons.values():
                button_rect = button.rect.inflate(-10, -10)
                
                if (rabbit.x < button_rect.right and 
                    rabbit.x + rabbit.size > button_rect.left and
                    rabbit.y < button_rect.bottom and 
                    rabbit.y + rabbit.size > button_rect.top):
                    
                    rabbit_center = (rabbit.x + rabbit.size/2, rabbit.y + rabbit.size/2)
                    button_center = button_rect.center
                    
                    #calculate push direction
                    dx = rabbit_center[0] - button_center[0]
                    dy = rabbit_center[1] - button_center[1]
                    dist = max(1, math.sqrt(dx*dx + dy*dy))
                    
                    #apply push force
                    push_x = (dx/dist) * rabbit.speed * 1.5
                    push_y = (dy/dist) * rabbit.speed * 1.5
                    
                    rabbit.x += push_x
                    rabbit.y += push_y
                    
                    #update rabbit direction
                    rabbit.direction = math.atan2(push_y, push_x)
                    rabbit.wander_timer = RABBIT_WANDER_TIME
    def draw(self):
        #fill background
        self.screen.fill(colours["rabbit_bg"])
        
        #draw all rabbits
        for rabbit in self.rabbits:
            rabbit.draw(self.screen)
        
        #draw all buttons
        for button in self.buttons.values():
            button.draw(self.screen)
        
        #draw title
        title = self.title_font.render("EvoSim", True, colours["title"])
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 200)))
        #draw fox cursor
        mouse_pos = pygame.mouse.get_pos()
        fox_img = pygame.transform.flip(self.fox_img, self.fox_facing_left, False)
        self.screen.blit(fox_img, fox_img.get_rect(center=mouse_pos))

class SimulationSelectionState(GameState):
    def init_ui(self):
        #set up button dimensions and starting position
        button_width, button_height = 450, 80
        start_y = SCREEN_HEIGHT // 2 - 100
        
        #create simulation selection buttons
        self.buttons = {
            'pred_prey': Button(SCREEN_WIDTH//2 - button_width//2, start_y,
                              button_width, button_height, "Predator vs Prey Simulation", self.button_font),
            'lotka_volterra': Button(SCREEN_WIDTH//2 - button_width//2, start_y + button_height + 30,
                                   button_width, button_height, "Lotka-Volterra Model", self.button_font),
            'evolution': Button(SCREEN_WIDTH//2 - button_width//2, start_y + 2*(button_height + 30),
                              button_width, button_height, "Genetic Evolution", self.button_font),
            'back': Button(50, 50, 120, 50, "Back", self.button_font)
        }
        
    def draw(self):
        #draw base ui elements
        super().draw()
        #draw page title
        title = self.title_font.render("Select Simulation Type", True, colours["title"])
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 150)))
        
class SettingsState(GameState):
    def init_ui(self):
        #set up button dimensions and starting position
        button_width, button_height = 400, 70
        start_y = SCREEN_HEIGHT // 2 - 150
        
        #create colour scheme selection buttons
        self.buttons = {
            'scheme_default': Button(SCREEN_WIDTH//2 - button_width//2, start_y, 
                                   button_width, button_height, "Default Colours", self.button_font),
            'scheme_high_contrast': Button(SCREEN_WIDTH//2 - button_width//2, start_y + button_height + 20,
                                         button_width, button_height, "High Contrast", self.button_font),
            'scheme_dark_blue': Button(SCREEN_WIDTH//2 - button_width//2, start_y + 2*(button_height + 20),
                                     button_width, button_height, "Dark Blue", self.button_font),
            'scheme_light_mode': Button(SCREEN_WIDTH//2 - button_width//2, start_y + 3*(button_height + 20),
                                      button_width, button_height, "Light Mode", self.button_font),
            'back': Button(50, 50, 120, 50, "Back", self.button_font)
        }
    def draw(self):
        #draw base ui elements
        super().draw()
        #draw page title
        title = self.title_font.render("Colour Settings", True, colours["title"])
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 150))) 

class LoadState(GameState):
    def __init__(self, screen):
        super().__init__(screen)
        #initialize state variables
        self.saved_sims = []
        self.selected_sim = None
        self.graph_image = None
        self.showing_details = False
        self.init_ui()
        self.load_saved_simulations()

    def init_ui(self):
        #set up button dimensions
        button_width, button_height = 120, 50
        #create list view buttons
        self.list_view_buttons = {
            'back': Button(50, 50, button_width, button_height, "Back", self.button_font),
            'view': Button(SCREEN_WIDTH - 170, SCREEN_HEIGHT - 70, 120, 50, "View", self.button_font),
            'refresh': Button(SCREEN_WIDTH - 310, SCREEN_HEIGHT - 70, 120, 50, "Refresh", self.button_font)
        }
        #create detail view button
        self.detail_view_button = {
            'back_to_list': Button(50, 50, 150, 50, "Back to List", self.button_font)
        }
        
        #define scrollable area
        self.scroll_area = pygame.Rect(50, 150, SCREEN_WIDTH - 100, SCREEN_HEIGHT - 250)
        self.scroll_y = 0
        self.max_scroll = 0

    def load_saved_simulations(self):
        """Load simulations and extract type from filename"""
        #reset simulation list and scroll position
        self.saved_sims = []
        self.scroll_y = 0
        
        #create directory if it doesn't exist
        if not os.path.exists("simulation_data"):
            os.makedirs("simulation_data")
            return
            
        #load all png files from simulation_data directory
        for filename in sorted(os.listdir("simulation_data"), reverse=True):
            if filename.lower().endswith(".png"):
                #extract type from filename (assumes format: TYPE_rest_of_name.png)
                sim_type = filename.split('_')[0].replace('-', ' ').title()
                
                self.saved_sims.append({
                    'filename': filename,
                    'image_path': os.path.join("simulation_data", filename),
                    'type': sim_type,  #the simplified type
                    'full_name': filename[:-4]  #full name without .png
                })
        
        #calculate maximum scroll distance
        self.max_scroll = max(0, len(self.saved_sims) * 60 - self.scroll_area.height)
        
    def handle_event(self, event):
        #handle detail view events
        if self.showing_details:
            if self.detail_view_button['back_to_list'].handle_event(event):
                self.showing_details = False
                self.load_saved_simulations()  #refresh list
                return None
        else:
            #handle list view button clicks
            button_clicked = None
            for name, button in self.list_view_buttons.items():
                if button.handle_event(event):
                    button_clicked = name
            
            if button_clicked == 'back':
                return 'back'
            elif button_clicked == 'refresh':
                self.load_saved_simulations()
            elif button_clicked == 'view' and self.selected_sim:
                self.showing_details = True
                self.load_selected_image()
                return None
            
            #handle mouse clicks and scrolling
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  #left click
                    #check if clicked on simulation entry
                    for i, sim in enumerate(self.saved_sims):
                        entry_rect = pygame.Rect(
                            self.scroll_area.x,
                            self.scroll_area.y + i*60 - self.scroll_y,
                            self.scroll_area.width,
                            55
                        )
                        if entry_rect.collidepoint(event.pos):
                            self.selected_sim = sim
                            return None
                            
                elif event.button == 4:  #mouse wheel up
                    self.scroll_y = max(0, self.scroll_y - 20)
                elif event.button == 5:  #mouse wheel down
                    self.scroll_y = min(self.max_scroll, self.scroll_y + 20)
                    
        return None

    def load_selected_image(self):
        """Load image with high-quality scaling"""
        if not self.selected_sim:
            return
            
        try:
            #load image directly without conversion
            img = pygame.image.load(self.selected_sim['image_path'])
            img_width, img_height = img.get_size()
            
            #calculate maximum display size while maintaining aspect ratio
            max_display_width = SCREEN_WIDTH - 100
            max_display_height = SCREEN_HEIGHT - 150
            
            scale = min(max_display_width/img_width, max_display_height/img_height)
            new_width = int(img_width * scale)
            new_height = int(img_height * scale)
            
            #use smooth scaling for better quality
            self.graph_image = pygame.transform.smoothscale(img, (new_width, new_height))
        except Exception as e:
            print(f"Error loading image: {e}")
            self.graph_image = None

    def draw_list_view(self):
        """Draw the list view showing filenames"""
        self.screen.fill(colours["background"])
        
        #draw title
        title = self.title_font.render("Saved Simulations", True, colours["title"])
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 100)))
        
        #draw scroll area background
        pygame.draw.rect(self.screen, colours["button"], self.scroll_area, border_radius=10)
        pygame.draw.rect(self.screen, colours["border"], self.scroll_area, width=2, border_radius=10)
        
        #set clipping area for scrollable content
        clip_rect = pygame.Rect(
            self.scroll_area.x + 2,
            self.scroll_area.y + 2,
            self.scroll_area.width - 4,
            self.scroll_area.height - 4
        )
        old_clip = self.screen.get_clip()
        self.screen.set_clip(clip_rect)
        
        #draw each simulation entry
        for i, sim in enumerate(self.saved_sims):
            entry_rect = pygame.Rect(
                self.scroll_area.x + 5,
                self.scroll_area.y + i*60 - self.scroll_y,
                self.scroll_area.width - 10,
                55
            )
            
            #highlight selected simulation
            if sim == self.selected_sim:
                pygame.draw.rect(self.screen, colours["button_hover"], entry_rect, border_radius=8)
            else:
                pygame.draw.rect(self.screen, colours["button"], entry_rect, border_radius=8)
                
            pygame.draw.rect(self.screen, colours["border"], entry_rect, width=1, border_radius=8)
            
            #draw filename (split into two lines if too long)
            name_text = self.button_font.render(sim['full_name'], True, colours["text"])
            self.screen.blit(name_text, (entry_rect.x + 15, entry_rect.y + 15))
        
        self.screen.set_clip(old_clip)
        
        #draw scroll bar if needed
        if self.max_scroll > 0:
            scroll_ratio = self.scroll_y / self.max_scroll
            scroll_height = max(30, self.scroll_area.height * (self.scroll_area.height / (len(self.saved_sims)*60)))
            scroll_pos = self.scroll_area.y + scroll_ratio * (self.scroll_area.height - scroll_height)
            
            scroll_rect = pygame.Rect(
                self.scroll_area.right - 10,
                scroll_pos,
                8,
                scroll_height
            )
            pygame.draw.rect(self.screen, colours["border_hover"], scroll_rect, border_radius=4)
        
        #draw buttons
        for name, button in self.list_view_buttons.items():
            if name == 'view' and not self.selected_sim:
                #draw disabled "View" button
                pygame.draw.rect(self.screen, (100, 100, 100), button.rect, border_radius=15)
                pygame.draw.rect(self.screen, (80, 80, 80), button.rect, width=2, border_radius=15)
                text = self.button_font.render("View", True, (150, 150, 150))
                self.screen.blit(text, text.get_rect(center=button.rect.center))
            else:
                button.draw(self.screen)

    def draw_detail_view(self):
        """Show only the type when viewing image"""
        self.screen.fill(colours["background"])
        
        #draw back button
        self.detail_view_button['back_to_list'].draw(self.screen)
        
        if self.graph_image:
            #changed to show only the type, not full filename
            title = self.title_font.render(
                f"{self.selected_sim['type']} Simulation", 
                True, 
                colours["title"]
            )
            self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 80)))
            
            #draw centered image
            img_rect = self.graph_image.get_rect(center=(SCREEN_WIDTH//2, SCREEN_HEIGHT//2 + 30))
            self.screen.blit(self.graph_image, img_rect)
            
    def draw(self):
        #choose which view to draw
        if self.showing_details:
            self.draw_detail_view()
        else:
            self.draw_list_view()

#tutorial state class inheriting from gamestate
class TutorialState(GameState):
    def __init__(self, screen):
        super().__init__(screen)
        #current page index
        self.current_page = 0
        #list of tutorial pages with title/content
        self.pages = [
            {
                "title": "Welcome to EvoSim",
                "content": [
                    "Welcome to the Multi-Simulator Evolution Application!",
                    "",
                    "This suite lets you explore ecology, evolution, and",
                    "population dynamics through interactive simulations.",
                    "",
                    "Features:",
                    "• Three different simulation types",
                    "• Real-time parameter adjustment",
                    "• Data visualization and graphs",
                    "• Save and load results",
                    "• Multiple colour schemes",
                    "",
                    "Use the buttons below to navigate through",
                    "this tutorial and learn about each simulation."
                ]
            },
            {
                "title": "Predator vs Prey Simulation",
                "content": [
                    "Real-time ecosystem simulation showing predator-prey",
                    "population dynamics.",
                    "",
                    "What you'll see:",
                    "• Green dots (prey) and red dots (predators)",
                    "• Real-time population graphs",
                    "• Cyclical population patterns",
                    "",
                    "How to use:",
                    "• Adjust populations in input boxes",
                    "• Modify speed and behavior settings",
                    "• Click START to begin",
                    "• Watch populations rise and fall naturally",
                    "",
                    "Demonstrates predator-prey relationships and cycles."
                ]
            },
            {
                "title": "Lotka-Volterra Model",
                "content": [
                    "Mathematical model showing how predator and prey",
                    "populations oscillate in predictable cycles.",
                    "",
                    "What you'll see:",
                    "• Population graphs with oscillating curves",
                    "• Phase portrait showing relationships",
                    "• Mathematical precision in dynamics",
                    "",
                    "How to use:",
                    "• Adjust growth rates and carrying capacity",
                    "• Set initial population values",
                    "• Click START to run simulation",
                    "• Observe time-series and phase plots",
                    "",
                    "Demonstrates mathematical ecosystem modeling."
                ]
            },
            {
                "title": "Genetic Evolution Simulation",
                "content": [
                    "Shows how creatures with different traits compete",
                    "and evolve over generations.",
                    "",
                    "What you'll see:",
                    "• Creatures with size, speed, vision traits",
                    "• Food sources in the environment",
                    "• Real-time trait evolution graphs",
                    "",
                    "How to use:",
                    "• Set creature count and reproduction rates",
                    "• Adjust mutation rates and pressures",
                    "• Click START to begin evolution",
                    "• Use DOWNLOAD to save results",
                    "",
                    "Demonstrates natural selection and adaptation."
                ]
            },
            {
                "title": "Navigation & Controls",
                "content": [
                    "Main Menu:",
                    "• Start New - Begin fresh simulation",
                    "• Load Saved - View previous results",
                    "• Tutorial - Access this help system",
                    "• Settings - Change colour schemes",
                    "",
                    "During Simulations:",
                    "• ESC key - Return to main menu",
                    "• Mouse - Interact with controls",
                    "• Parameter boxes - Modify settings",
                    "• START/PAUSE - Control execution",
                    "",
                    "Results saved to 'simulation_data' folder."
                ]
            },
            {
                "title": "Tips & Best Practices",
                "content": [
                    "Getting the most from your simulations:",
                    "",
                    "Experimentation:",
                    "• Start with defaults, then modify gradually",
                    "• Try extreme values to see boundaries",
                    "• Compare different parameter sets",
                    "",
                    "Analysis:",
                    "• Watch for population patterns",
                    "• Note how changes affect stability",
                    "• Save interesting results",
                    "",
                    "Use Settings for different colour schemes."
                ]
            }
        ]
        self.init_ui()

    #initialize ui elements
    def init_ui(self):
        #navigation buttons dictionary
        self.buttons = {
            'prev': Button(50, SCREEN_HEIGHT - 80, 150, 50, "Previous", self.button_font),
            'next': Button(SCREEN_WIDTH - 200, SCREEN_HEIGHT - 80, 150, 50, "Next", self.button_font),
            'back': Button(SCREEN_WIDTH//2 - 75, SCREEN_HEIGHT - 80, 150, 50, "Back", self.button_font)
        }

    #handle button events
    def handle_event(self, event):
        button_clicked = super().handle_event(event)
        if button_clicked == 'next':
            #advance page with bounds check
            self.current_page = min(len(self.pages)-1, self.current_page + 1)
        elif button_clicked == 'prev':
            #go back page with bounds check
            self.current_page = max(0, self.current_page - 1)
        elif button_clicked == 'back':
            return 'back'
        return None

    #draw tutorial screen
    def draw(self):
        self.screen.fill(colours["background"])
        
        #draw title
        title = self.title_font.render(self.pages[self.current_page]["title"], True, colours["title"])
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 80)))
        
        #draw content with proper centering
        content_y = 140
        line_height = 32
        max_lines = 15  #limit lines to prevent overflow
        
        content_lines = self.pages[self.current_page]["content"][:max_lines]
        
        for line in content_lines:
            if line.strip():  #non-empty line
                text = self.button_font.render(line, True, colours["text"])
                #center each line horizontally
                text_rect = text.get_rect(center=(SCREEN_WIDTH//2, content_y))
                self.screen.blit(text, text_rect)
            content_y += line_height if line.strip() else line_height // 2  #less space for empty lines
        
        #draw page indicator
        page_text = self.small_font.render(
            f"Page {self.current_page + 1} of {len(self.pages)}", 
            True, 
            colours["text"]
        )
        self.screen.blit(page_text, (SCREEN_WIDTH - 150, 30))
        
        #draw buttons (hide prev button on first page, next on last)
        if self.current_page > 0:
            self.buttons['prev'].draw(self.screen)
        if self.current_page < len(self.pages) - 1:
            self.buttons['next'].draw(self.screen)
        self.buttons['back'].draw(self.screen)

#base simulation state class inheriting from gamestate
class SimulationState(GameState):
    def __init__(self, screen, title):
        super().__init__(screen)
        #store simulation title
        self.title = title
        self.init_ui()

    #initialize user interface elements
    def init_ui(self):
        #create back button
        self.buttons['back'] = Button(50, 50, 120, 50, "Back", self.button_font)

    #draw simulation screen
    def draw(self):
        super().draw()
        #render and center title text
        title = self.title_font.render(self.title, True, colours["title"])
        self.screen.blit(title, title.get_rect(center=(SCREEN_WIDTH//2, 150)))

#main application class managing game states and flow
class App:
    def __init__(self):
        pygame.init()
        #initialize screen and basic pygame setup
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Evolution Simulator")
        self.clock = pygame.time.Clock()
        #dictionary of all possible application states
        self.states = {
            'home': HomePage(self.screen),
            'simulation_selection': SimulationSelectionState(self.screen),
            'pred_prey': SimulationState(self.screen, "Predator vs Prey Simulation"),
            'lotka_volterra': SimulationState(self.screen, "Lotka-Volterra Model"),
            'evolution': SimulationState(self.screen, "Genetic Evolution"),
            'load': LoadState(self.screen),
            'tutorial': TutorialState(self.screen),
            'settings': SettingsState(self.screen)
        }
        self.current_state = 'home'  #start with home state
        pygame.mouse.set_visible(False)  #hide mouse cursor initially

    #main game loop
    def run(self):
        while True:
            #event handling
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                #escape key returns to home screen
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.current_state != 'home':
                        self.current_state = 'home'
                        continue
                
                #delegate event to current state
                button_clicked = self.states[self.current_state].handle_event(event)
                if button_clicked:
                    self.handle_button(button_clicked)

            #update and draw current state
            self.states[self.current_state].update()
            self.states[self.current_state].draw()
            pygame.display.flip()
            self.clock.tick(FPS)  #maintain consistent framerate

    #run predator-prey simulation
    def run_pred_prey_simulation(self):
        """Execute PredVSPrey simulation directly"""
        try:
            import PredVSPrey
            PredVSPrey.run_simulation(colour_manager.current_scheme)
            
            #reinitialize display after simulation ends
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.display.set_caption("EvoSim")  
            
            #force redraw of main menu
            self.draw()
            pygame.display.flip()
            
            self.current_state = 'simulation_selection'
            
        except ImportError:
            print("Error: PredVSPrey.py not found")
            self.show_error_message("Simulation file not found!")
        except Exception as e:
            pass

    #run lotka-volterra simulation
    def run_lotka_volterra_simulation(self):
        """Execute Lokta-Volterra simulation directly"""
        try:
            import LoktaVolterra  #replace with actual filename
            LoktaVolterra.run_simulation(colour_manager.current_scheme)
            
            #reinitialize display after simulation ends
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.display.set_caption("EvoSim")  
            
            #force redraw of main menu
            self.draw()
            pygame.display.flip()
            
            self.current_state = 'simulation_selection'
            
        except ImportError:
            print("Error: LoktaVolterra.py not found")
            self.show_error_message("Simulation file not found!")
        except Exception as e:
            pass
            
    #run genetic evolution simulation        
    def run_genetic_evolution_simulation(self):
        """Execute Genetic Evolution simulation directly"""
        try:
            import GeneticEvolution  #replace with actual filename
            GeneticEvolution.run_simulation(colour_manager.current_scheme)
            
            #reinitialize display after simulation ends
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
            pygame.display.set_caption("EvoSim")
            
            #force redraw of main menu
            self.draw()
            pygame.display.flip()
            
            self.current_state = 'simulation_selection'
            
        except ImportError:
            print("Error: GeneticEvolution.py not found")
            self.show_error_message("Simulation file not found!")
        except Exception as e:
            pass   
            
    #display error message on screen        
    def show_error_message(self, message):
        """Helper to show error messages"""
        if pygame.display.get_init() == 0:
            pygame.display.init()
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        self.screen.fill(colours["background"])
        error_font = pygame.font.Font(None, 36)
        error_text = error_font.render(message, True, (255, 0, 0))
        self.screen.blit(error_text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2))
        pygame.display.flip()
        pygame.time.wait(2000)  #show message for 2 seconds
    
    #restore main application window    
    def restore_main_window(self):
        """Restores and brings the main window to front"""
        #ensure display is initialized
        if pygame.display.get_init() == 0:
            pygame.display.init()
            self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        #restore from minimized state
        pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        #platform-specific window management
        if sys.platform == 'win32':
            import ctypes
            try:
                hwnd = pygame.display.get_wm_info()['window']
                ctypes.windll.user32.ShowWindow(hwnd, 9)  #sw_restore = 9
                ctypes.windll.user32.SetForegroundWindow(hwnd)
            except:
                pass
        elif sys.platform == 'darwin':  #macos
            import subprocess
            subprocess.run(['osascript', '-e', 'tell application "System Events" to set frontmost of process "python" to true'])

    #handle button press actions        
    def handle_button(self, button_name):
        #handle colour scheme changes
        if button_name.startswith('scheme_'):
            scheme_name = button_name[7:]
            if scheme_name in COLOUR_SCHEMES:
                colour_manager.current_scheme = scheme_name
                colour_manager.save_settings()
                global colours
                colours = colour_manager.get_colours()
            return
        
        #map button names to state transitions
        state_map = {
            'new': 'simulation_selection',
            'back': 'simulation_selection' if self.current_state in ['pred_prey', 'lotka_volterra', 'evolution'] else 'home',
            'pred_prey': self.run_pred_prey_simulation,
            'lotka_volterra': self.run_lotka_volterra_simulation,
            'evolution': self.run_genetic_evolution_simulation,
            'load': 'load',
            'tutorial': 'tutorial',
            'settings': 'settings'
        }
        
        #execute appropriate action for button
        action = state_map.get(button_name, 'home')
        if callable(action):
            action()  #execute method
        else:
            self.current_state = action  #set new state
        
        #show/hide mouse cursor based on state
        pygame.mouse.set_visible(self.current_state != 'home')
        
#main entry point for the application
if __name__ == "__main__":
    #check for required image files before starting
    if not all(os.path.exists(f) for f in ['rabbit.png', 'fox.png']):
        print("Error: Missing required image files")
        sys.exit(1)  #exit if files are missing
    #create and run the application
    App().run()