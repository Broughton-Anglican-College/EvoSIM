import pygame
import sys
import random
import math
from datetime import datetime
import json
import os

#screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
TARGET_FPS = 60

#colour schemes
COLOUR_SCHEMES = {
    "default": {
        "background": (64, 64, 64),
        "text": (255, 255, 255),
        "button": (30, 30, 30),
        "button_hover": (40, 40, 40),
        "border": (80, 80, 80),
        "border_hover": (100, 100, 100),
        "title": (255, 255, 255),
        "sim_bg": (200, 200, 200),
        "creature": (200, 200, 50),
        "food": (50, 200, 50),
        "graph_bg": (255, 255, 255),
        "input_bg": (220, 220, 220),
        "input_text": (0, 0, 0),
        "trait_size": (255, 100, 100),
        "trait_speed": (100, 255, 100),
        "trait_vision": (100, 100, 255),
        "slider": (100, 100, 100),
        "slider_handle": (150, 150, 150),
        "input_highlight": (255, 255, 200)
    },
    "high_contrast": {
        "background": (0, 0, 0),
        "text": (255, 255, 255),
        "button": (0, 0, 0),
        "button_hover": (50, 50, 50),
        "border": (255, 255, 255),
        "border_hover": (255, 255, 0),
        "title": (255, 255, 0),
        "sim_bg": (50, 50, 50),
        "creature": (255, 255, 0),
        "food": (0, 255, 0),
        "graph_bg": (0, 0, 0),
        "input_bg": (30, 30, 30),
        "input_text": (255, 255, 255),
        "trait_size": (255, 0, 0),
        "trait_speed": (0, 255, 0),
        "trait_vision": (0, 0, 255),
        "slider": (100, 100, 100),
        "slider_handle": (200, 200, 200),
        "input_highlight": (83, 83, 83)
    },
    "dark_blue": {
        "background": (0, 0, 50),
        "text": (200, 200, 255),
        "button": (0, 0, 80),
        "button_hover": (0, 0, 120),
        "border": (100, 100, 255),
        "border_hover": (150, 150, 255),
        "title": (200, 200, 255),
        "sim_bg": (0, 0, 70),
        "creature": (255, 255, 100),
        "food": (100, 255, 100),
        "graph_bg": (0, 0, 30),
        "input_bg": (0, 0, 90),
        "input_text": (200, 200, 255),
        "trait_size": (255, 100, 100),
        "trait_speed": (100, 255, 100),
        "trait_vision": (100, 100, 255),
        "slider": (50, 50, 100),
        "slider_handle": (100, 100, 150),
        "input_highlight": (68, 85, 90)
    },
    "light_mode": {
        "background": (240, 240, 240),
        "text": (0, 0, 0),
        "button": (220, 220, 220),
        "button_hover": (200, 200, 200),
        "border": (100, 100, 100),
        "border_hover": (50, 50, 50),
        "title": (0, 0, 0),
        "sim_bg": (255, 255, 255),
        "creature": (200, 150, 0),
        "food": (0, 180, 0),
        "graph_bg": (255, 255, 255),
        "input_bg": (255, 255, 255),
        "input_text": (0, 0, 0),
        "trait_size": (220, 50, 50),
        "trait_speed": (50, 180, 50),
        "trait_vision": (50, 50, 220),
        "slider": (180, 180, 180),
        "slider_handle": (120, 120, 120),
        "input_highlight": (255, 255, 180)
    }
}

colours = None

#initialize pygame fonts
pygame.init()
FONT = pygame.font.Font(None, 24)
TITLE_FONT = pygame.font.Font(None, 36)

class Button:
    def __init__(self, x, y, width, height, text, font):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.hovered = False
        
    def draw(self, screen):
        colour = colours["button_hover"] if self.hovered else colours["button"]
        border_colour = colours["border_hover"] if self.hovered else colours["border"]
        
        pygame.draw.rect(screen, colour, self.rect, border_radius=15)
        pygame.draw.rect(screen, border_colour, self.rect, width=2, border_radius=15)
        
        text_surface = self.font.render(self.text, True, colours["text"])
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)
    
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                return True
        return False

class InputBox:
    def __init__(self, x, y, w, h, text='', description=''):
        self.rect = pygame.Rect(x, y, w, h)
        self.colour = colours["input_bg"]
        self.text = text
        self.default_text = text
        self.description = description
        self.txt_surface = FONT.render(text, True, colours["input_text"])
        self.active = False
        self.font = FONT
        self.desc_font = pygame.font.Font(None, 20)
        
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = True
                self.colour = colours["input_highlight"]  #highlight when active
                if self.text == self.default_text:
                    self.text = ''
            else:
                self.active = False
                self.colour = colours["input_bg"]
                if not self.text:
                    self.text = self.default_text
            
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    self.active = False
                    self.colour = colours["input_bg"]
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                self.txt_surface = self.font.render(self.text, True, colours["input_text"])
    
    def get_value(self):
        try:
            return float(self.text) if '.' in self.text else int(self.text)
        except ValueError:
            return 0
    
    def draw(self, screen):
        screen.blit(self.desc_font.render(self.description, True, colours["text"]), (self.rect.x, self.rect.y - 18))
        pygame.draw.rect(screen, self.colour, self.rect, 0, 5)
        pygame.draw.rect(screen, colours["border"], self.rect, 2, 5)
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

class Slider:
    def __init__(self, x, y, w, h, min_val=0.1, max_val=10, initial_val=1):
        self.rect = pygame.Rect(x, y, w, h)
        self.min_val = min_val
        self.max_val = max_val
        self.val = initial_val
        self.dragging = False
        self.handle_radius = h * 1.5
        self.handle_x = self.value_to_pos(initial_val)
        
    def value_to_pos(self, value):
        return self.rect.left + (value - self.min_val) / (self.max_val - self.min_val) * self.rect.width
    
    def pos_to_value(self, pos):
        return self.min_val + (pos - self.rect.left) / self.rect.width * (self.max_val - self.min_val)
    
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if (math.hypot(event.pos[0] - self.handle_x, event.pos[1] - (self.rect.centery)) < self.handle_radius or
                self.rect.collidepoint(event.pos)):
                self.dragging = True
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self.handle_x = max(self.rect.left, min(event.pos[0], self.rect.right))
            self.val = self.pos_to_value(self.handle_x)
            return True
        return False
    
    def draw(self, screen):
        #draw track
        pygame.draw.rect(screen, colours["slider"], self.rect, border_radius=5)
        pygame.draw.rect(screen, colours["border"], self.rect, 2, 5)
        
        #draw handle
        pygame.draw.circle(screen, colours["slider_handle"], (int(self.handle_x), self.rect.centery), int(self.handle_radius))
        
        #draw value text
        value_text = FONT.render(f"{self.val:.1f}x", True, colours["text"])
        screen.blit(value_text, (self.rect.right + 10, self.rect.centery - 10))

class Creature:
    def __init__(self, x, y, size, speed, vision, params):
        self.x = x
        self.y = y
        self.size = size
        self.speed = speed
        self.vision = vision
        self.energy = 200
        self.direction = random.uniform(0, 2 * math.pi)
        self.params = params
        
    def move(self, foods, sim_rect):
        #find closest food in vision range
        closest_food = None
        min_dist = float('inf')
        
        for food in foods:
            dist = math.hypot(food.x - self.x, food.y - self.y)
            if dist < min_dist and dist <= self.vision:
                min_dist = dist
                closest_food = food
        
        #adjust direction based on food or wander randomly
        if closest_food:
            target_angle = math.atan2(closest_food.y - self.y, closest_food.x - self.x)
            angle_diff = (target_angle - self.direction + math.pi) % (2 * math.pi) - math.pi
            self.direction += angle_diff * 0.2
        else:
            self.direction += random.uniform(-0.15, 0.15)
            
        self.direction %= 2 * math.pi
        
        #calculate new position
        new_x = self.x + math.cos(self.direction) * self.speed
        new_y = self.y + math.sin(self.direction) * self.speed
        
        #bounce off walls
        if new_x < sim_rect.left + self.size or new_x > sim_rect.right - self.size:
            self.direction = math.pi - self.direction
            new_x = max(sim_rect.left + self.size, min(new_x, sim_rect.right - self.size))
            
        if new_y < sim_rect.top + self.size or new_y > sim_rect.bottom - self.size:
            self.direction = -self.direction
            new_y = max(sim_rect.top + self.size, min(new_y, sim_rect.bottom - self.size))
        
        self.x = new_x
        self.y = new_y
        #energy loss based on speed and size
        self.energy -= 0.2 + (self.speed * 0.1) + (self.size * 0.05)
    
    def eat(self, foods):
        for food in foods[:]:
            if math.hypot(food.x - self.x, food.y - self.y) < self.size + 5:
                self.energy += 50
                foods.remove(food)
                return True
        return False
    
    def reproduce(self):
        if self.energy > 200 and random.random() < self.params['repro_rate'] / 100:
            self.energy -= 100
            return Creature(
                x=self.x + random.uniform(-20, 20),
                y=self.y + random.uniform(-20, 20),
                size=max(1.0, self.size + random.uniform(-0.2, 0.2)),
                speed=max(0.5, self.speed + random.uniform(-0.1, 0.1)),
                vision=max(20, self.vision + random.uniform(-10, 10)),
                params=self.params
            )
        return None
    
    def draw(self, screen):
        #adjust colour based on energy level
        energy_ratio = min(1.0, max(0.3, self.energy / 200))
        colour = (
            int(colours["creature"][0] * energy_ratio),
            int(colours["creature"][1] * energy_ratio),
            int(colours["creature"][2] * energy_ratio)
        )
        pygame.draw.circle(screen, colour, (int(self.x), int(self.y)), int(self.size))

class Food:
    def __init__(self, x=None, y=None, sim_rect=None):
        if sim_rect:
            self.x = random.uniform(sim_rect.left + 10, sim_rect.right - 10)
            self.y = random.uniform(sim_rect.top + 10, sim_rect.bottom - 10)
        else:
            self.x = x if x is not None else random.uniform(40, 680)
            self.y = y if y is not None else random.uniform(70, 590)
        
    def draw(self, screen):
        pygame.draw.circle(screen, colours["food"], (int(self.x), int(self.y)), 4)

class GeneticEvolutionSim:
    def __init__(self, screen):
        self.screen = screen
        self.font_title = TITLE_FONT
        self.font_ui = FONT
        self.font_button = pygame.font.Font(None, 26)
        
        #simulation area
        self.sim_rect = pygame.Rect(20, 80, 700, 570)
        self.creatures = []
        self.foods = []
        self.running = False
        self.time_step = 0
        self.sim_speed = 1.0
        self.history = {
            'creature_count': [],
            'food_count': [],
            'avg_size': [],
            'avg_speed': [],
            'avg_vision': [],
            'time': []
        }
        
        #control buttons
        self.buttons = {
            'start_pause': Button(740, 20, 100, 40, "START", self.font_button),
            'reset': Button(850, 20, 80, 40, "RESET", self.font_button),
            'download': Button(940, 20, 120, 40, "DOWNLOAD", self.font_button),
            'back': Button(1070, 20, 80, 40, "BACK", self.font_button)
        }
        
        #input parameters
        self.input_boxes = [
            InputBox(740, 100, 100, 30, '25', 'Initial Creatures'),
            InputBox(740, 150, 100, 30, '100', 'Max Creatures'),
            InputBox(740, 200, 100, 30, '3', 'Repro Rate %'),
            InputBox(860, 100, 100, 30, '100', 'Initial Food'),
            InputBox(860, 150, 100, 30, '200', 'Max Food'),
            InputBox(860, 200, 100, 30, '5', 'Food Spawn/s')
        ]
        
        #simulation speed slider
        self.speed_slider = Slider(740, 660, 220, 10, 0.1, 10, 1)
        
        #graph areas
        self.graph_top = 270
        self.pop_graph_rect = pygame.Rect(740, self.graph_top, 520, 150)
        self.trait_graph_rect = pygame.Rect(740, self.graph_top + 180, 520, 150)
        
        self.init_simulation()

    def get_params(self):
        return {
            'initial_creatures': int(self.input_boxes[0].get_value()),
            'initial_food': int(self.input_boxes[3].get_value()),
            'max_creatures': int(self.input_boxes[1].get_value()),
            'repro_rate': float(self.input_boxes[2].get_value()),
            'food_spawn_rate': float(self.input_boxes[5].get_value()),
            'max_food': int(self.input_boxes[4].get_value())
        }

    def init_simulation(self):
        """reset simulation with current parameters"""
        self.creatures = []
        self.foods = []
        self.time_step = 0
        self.history = {k: [] for k in self.history}
        params = self.get_params()
        
        #create initial creatures
        for _ in range(params['initial_creatures']):
            self.creatures.append(Creature(
                x=random.uniform(self.sim_rect.left + 30, self.sim_rect.right - 30),
                y=random.uniform(self.sim_rect.top + 30, self.sim_rect.bottom - 30),
                size=random.uniform(1.5, 3.5),
                speed=random.uniform(1.0, 3.0),
                vision=random.uniform(30, 100),
                params=params
            ))
        
        #create initial food
        for _ in range(params['initial_food']):
            self.foods.append(Food(sim_rect=self.sim_rect))
        
        self.running = False
        self.buttons['start_pause'].text = "START"

    def handle_event(self, event):
        #handle back button first
        if self.buttons['back'].handle_event(event):
            return "back"
            
        #handle other buttons
        for name, button in self.buttons.items():
            if name != 'back' and button.handle_event(event):
                if name == 'start_pause':
                    self.running = not self.running
                    button.text = "PAUSE" if self.running else "START"
                elif name == 'reset':
                    self.init_simulation()
                elif name == 'download':
                    self.download_data()
        
        #handle input boxes
        for box in self.input_boxes:
            box.handle_event(event)
        
        #handle speed slider
        if self.speed_slider.handle_event(event):
            self.sim_speed = self.speed_slider.val

    def update(self):
        if not self.running:
            return
            
        #update simulation based on current speed
        steps = max(1, int(self.sim_speed))
        for _ in range(steps):
            self.time_step += 1
            params = self.get_params()
            
            #spawn new food
            if random.random() < params['food_spawn_rate'] / TARGET_FPS:
                if len(self.foods) < params['max_food']:
                    self.foods.append(Food(sim_rect=self.sim_rect))
            
            new_creatures = []
            dead_creatures = []
            
            #update all creatures
            for creature in self.creatures:
                if creature.energy <= 0:
                    dead_creatures.append(creature)
                    continue
                    
                creature.move(self.foods, self.sim_rect)
                creature.eat(self.foods)
                
                #check for reproduction
                if new_creature := creature.reproduce():
                    new_creatures.append(new_creature)
            
            #update creature lists
            self.creatures = [c for c in self.creatures if c not in dead_creatures]
            self.creatures.extend(new_creatures)
            
            #enforce population limit
            if len(self.creatures) > params['max_creatures']:
                self.creatures = self.creatures[:params['max_creatures']]
            
            #update history periodically
            if self.time_step % (30 // steps) == 0:
                self.history['creature_count'].append(len(self.creatures))
                self.history['food_count'].append(len(self.foods))
                
                if self.creatures:
                    self.history['avg_size'].append(sum(c.size for c in self.creatures) / len(self.creatures))
                    self.history['avg_speed'].append(sum(c.speed for c in self.creatures) / len(self.creatures))
                    self.history['avg_vision'].append(sum(c.vision for c in self.creatures) / len(self.creatures))
                else:
                    self.history['avg_size'].append(0)
                    self.history['avg_speed'].append(0)
                    self.history['avg_vision'].append(0)
                    
                self.history['time'].append(self.time_step / TARGET_FPS)
                
                #limit history size
                max_history = 1000
                for key in self.history:
                    if len(self.history[key]) > max_history:
                        self.history[key] = self.history[key][-max_history:]

    def draw(self):
        self.screen.fill(colours["background"])
        
        #draw title
        title_text = self.font_title.render("Genetic Evolution Simulation", True, colours["title"])
        self.screen.blit(title_text, (20, 20))
        
        #draw status info
        status = "RUNNING" if self.running else "PAUSED"
        status_text = self.font_ui.render(f"Status: {status}", True, colours["text"])
        self.screen.blit(status_text, (20, 660))
        
        count_text = self.font_ui.render(
            f"Creatures: {len(self.creatures)} | Food: {len(self.foods)}", 
            True, colours["text"]
        )
        self.screen.blit(count_text, (20, 685))
        
        time_text = self.font_ui.render(f"Time: {self.time_step / TARGET_FPS:.1f}s", True, colours["text"])
        self.screen.blit(time_text, (300, 660))
        
        #draw simulation area
        pygame.draw.rect(self.screen, colours["sim_bg"], self.sim_rect)
        pygame.draw.rect(self.screen, colours["border"], self.sim_rect, 2)
        
        #draw food and creatures
        for food in self.foods:
            food.draw(self.screen)
        
        for creature in self.creatures:
            creature.draw(self.screen)
        
        #draw controls
        for box in self.input_boxes:
            box.draw(self.screen)
        
        for button in self.buttons.values():
            button.draw(self.screen)
        
        #draw speed slider
        speed_label = FONT.render("Simulation Speed:", True, colours["text"])
        self.screen.blit(speed_label, (740, 630))
        self.speed_slider.draw(self.screen)
        
        #draw graphs
        self.draw_population_graph()
        self.draw_traits_graph()

    def draw_population_graph(self):
        pygame.draw.rect(self.screen, colours["graph_bg"], self.pop_graph_rect)
        pygame.draw.rect(self.screen, colours["border"], self.pop_graph_rect, 2)
        
        if len(self.history['time']) > 1:
            max_pop = max(max(self.history['creature_count'] + [1]), max(self.history['food_count'] + [1]))
            min_pop = min(min(self.history['creature_count'] + [0]), min(self.history['food_count'] + [0]))
            range_pop = max_pop - min_pop if max_pop != min_pop else 1
            
            #draw creature population line
            points = []
            for i, count in enumerate(self.history['creature_count']):
                x = self.pop_graph_rect.left + (i / (len(self.history['creature_count']) - 1)) * self.pop_graph_rect.width
                y = self.pop_graph_rect.bottom - ((count - min_pop) / range_pop) * self.pop_graph_rect.height
                points.append((x, y))
            if len(points) > 1:
                pygame.draw.lines(self.screen, colours["creature"], False, points, 2)
            
            #draw food population line
            points = []
            for i, count in enumerate(self.history['food_count']):
                x = self.pop_graph_rect.left + (i / (len(self.history['food_count']) - 1)) * self.pop_graph_rect.width
                y = self.pop_graph_rect.bottom - ((count - min_pop) / range_pop) * self.pop_graph_rect.height
                points.append((x, y))
            if len(points) > 1:
                pygame.draw.lines(self.screen, colours["food"], False, points, 2)
        
        #draw graph title
        title = self.font_ui.render("Population Over Time", True, colours["text"])
        self.screen.blit(title, (self.pop_graph_rect.left, self.pop_graph_rect.top - 25))
        
        #draw legends
        creature_legend = self.font_ui.render("Creatures", True, colours["creature"])
        food_legend = self.font_ui.render("Food", True, colours["food"])
        self.screen.blit(creature_legend, (self.pop_graph_rect.left + 440, self.pop_graph_rect.bottom + 5))
        self.screen.blit(food_legend, (self.pop_graph_rect.left + 390, self.pop_graph_rect.bottom + 5))

    def draw_traits_graph(self):
        pygame.draw.rect(self.screen, colours["graph_bg"], self.trait_graph_rect)
        pygame.draw.rect(self.screen, colours["border"], self.trait_graph_rect, 2)
        
        if len(self.history['time']) > 1:
            max_size = max(self.history['avg_size'] + [5])
            min_size = min(self.history['avg_size'] + [0])
            range_size = max_size - min_size if max_size != min_size else 1
            
            max_speed = max(self.history['avg_speed'] + [5])
            min_speed = min(self.history['avg_speed'] + [0])
            range_speed = max_speed - min_speed if max_speed != min_speed else 1
            
            max_vision = max(self.history['avg_vision'] + [100])
            min_vision = min(self.history['avg_vision'] + [0])
            range_vision = max_vision - min_vision if max_vision != min_vision else 1
            
            #draw size line
            points = []
            for i, val in enumerate(self.history['avg_size']):
                x = self.trait_graph_rect.left + (i / (len(self.history['avg_size']) - 1)) * self.trait_graph_rect.width
                y = self.trait_graph_rect.bottom - ((val - min_size) / range_size) * self.trait_graph_rect.height
                points.append((x, y))
            if len(points) > 1:
                pygame.draw.lines(self.screen, colours["trait_size"], False, points, 2)
            
            #draw speed line
            points = []
            for i, val in enumerate(self.history['avg_speed']):
                x = self.trait_graph_rect.left + (i / (len(self.history['avg_speed']) - 1)) * self.trait_graph_rect.width
                y = self.trait_graph_rect.bottom - ((val - min_speed) / range_speed) * self.trait_graph_rect.height
                points.append((x, y))
            if len(points) > 1:
                pygame.draw.lines(self.screen, colours["trait_speed"], False, points, 2)
            
            #draw vision line
            points = []
            for i, val in enumerate(self.history['avg_vision']):
                x = self.trait_graph_rect.left + (i / (len(self.history['avg_vision']) - 1)) * self.trait_graph_rect.width
                y = self.trait_graph_rect.bottom - ((val - min_vision) / range_vision) * self.trait_graph_rect.height
                points.append((x, y))
            if len(points) > 1:
                pygame.draw.lines(self.screen, colours["trait_vision"], False, points, 2)
        
        #draw graph title
        title = self.font_ui.render("Average Traits Over Time", True, colours["text"])
        self.screen.blit(title, (self.trait_graph_rect.left, self.trait_graph_rect.top - 25))
        
        #draw legends
        size_legend = self.font_ui.render("Size", True, colours["trait_size"])
        speed_legend = self.font_ui.render("Speed", True, colours["trait_speed"])
        vision_legend = self.font_ui.render("Vision", True, colours["trait_vision"])
        self.screen.blit(size_legend, (self.trait_graph_rect.left + 10, self.trait_graph_rect.bottom + 5))
        self.screen.blit(speed_legend, (self.trait_graph_rect.left + 80, self.trait_graph_rect.bottom + 5))
        self.screen.blit(vision_legend, (self.trait_graph_rect.left + 150, self.trait_graph_rect.bottom + 5))

    def download_data(self):
        """save simulation data and graphs as image"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"genetic_evolution_{timestamp}.png"
        os.makedirs("simulation_data", exist_ok=True)
        filepath = os.path.join("simulation_data", filename)
    
        try:
            #fixed colours for saved image
            SAVE_COLOURS = {
                "bg": (255, 255, 255),
                "graph_bg": (240, 240, 240),
                "border": (100, 100, 100),
                "grid": (220, 220, 220),
                "text": (0, 0, 0),
                "creature": (200, 150, 0),
                "food": (0, 180, 0),
                "size": (200, 50, 50),
                "speed": (50, 180, 50),
                "vision": (50, 50, 200),
                "legend_box": (200, 200, 200)
            }
    
            #create image surface
            graph_width = 1000
            graph_height = 820
            graph_surface = pygame.Surface((graph_width, graph_height))
            graph_surface.fill(SAVE_COLOURS["bg"])
    
            #layout parameters
            padding = 20
            title_spacing = 40
            graph_area_height = 350
    
            #draw population graph
            pop_graph_rect = pygame.Rect(padding, title_spacing, graph_width - 2*padding, graph_area_height)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["graph_bg"], pop_graph_rect)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["border"], pop_graph_rect, 2)
    
            if len(self.history['time']) > 1:
                max_pop = max(max(self.history['creature_count'] + [1]), max(self.history['food_count'] + [1]))
                min_pop = min(min(self.history['creature_count'] + [0]), min(self.history['food_count'] + [0]))
                range_pop = max_pop - min_pop if max_pop != min_pop else 1
                
                #draw grid lines
                for i in range(5):
                    y = pop_graph_rect.bottom - i * pop_graph_rect.height // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (pop_graph_rect.left, y),
                                   (pop_graph_rect.right, y), 1)
                    
                    x = pop_graph_rect.left + i * pop_graph_rect.width // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (x, pop_graph_rect.top),
                                   (x, pop_graph_rect.bottom), 1)
                
                #draw creature line
                if self.history['creature_count']:
                    points = []
                    for i, count in enumerate(self.history['creature_count']):
                        x = pop_graph_rect.left + (i / (len(self.history['creature_count']) - 1)) * pop_graph_rect.width
                        y = pop_graph_rect.bottom - ((count - min_pop) / range_pop) * pop_graph_rect.height
                        points.append((x, y))
                    if len(points) > 1:
                        pygame.draw.lines(graph_surface, SAVE_COLOURS["creature"], False, points, 3)
                
                #draw food line
                if self.history['food_count']:
                    points = []
                    for i, count in enumerate(self.history['food_count']):
                        x = pop_graph_rect.left + (i / (len(self.history['food_count']) - 1)) * pop_graph_rect.width
                        y = pop_graph_rect.bottom - ((count - min_pop) / range_pop) * pop_graph_rect.height
                        points.append((x, y))
                    if len(points) > 1:
                        pygame.draw.lines(graph_surface, SAVE_COLOURS["food"], False, points, 3)
    
            #draw traits graph
            trait_graph_rect = pygame.Rect(padding, pop_graph_rect.bottom + 40, graph_width - 2*padding, graph_area_height)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["graph_bg"], trait_graph_rect)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["border"], trait_graph_rect, 2)
    
            if len(self.history['time']) > 1:
                max_size = max(self.history['avg_size'] + [5])
                min_size = min(self.history['avg_size'] + [0])
                range_size = max_size - min_size if max_size != min_size else 1
                
                max_speed = max(self.history['avg_speed'] + [5])
                min_speed = min(self.history['avg_speed'] + [0])
                range_speed = max_speed - min_speed if max_speed != min_speed else 1
                
                max_vision = max(self.history['avg_vision'] + [100])
                min_vision = min(self.history['avg_vision'] + [0])
                range_vision = max_vision - min_vision if max_vision != min_vision else 1
                
                #draw grid lines
                for i in range(5):
                    y = trait_graph_rect.bottom - i * trait_graph_rect.height // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (trait_graph_rect.left, y),
                                   (trait_graph_rect.right, y), 1)
                    
                    x = trait_graph_rect.left + i * trait_graph_rect.width // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (x, trait_graph_rect.top),
                                   (x, trait_graph_rect.bottom), 1)
                
                #draw size line
                if self.history['avg_size']:
                    points = []
                    for i, val in enumerate(self.history['avg_size']):
                        x = trait_graph_rect.left + (i / (len(self.history['avg_size']) - 1)) * trait_graph_rect.width
                        y = trait_graph_rect.bottom - ((val - min_size) / range_size) * trait_graph_rect.height
                        points.append((x, y))
                    if len(points) > 1:
                        pygame.draw.lines(graph_surface, SAVE_COLOURS["size"], False, points, 2)
                
                #draw speed line
                if self.history['avg_speed']:
                    points = []
                    for i, val in enumerate(self.history['avg_speed']):
                        x = trait_graph_rect.left + (i / (len(self.history['avg_speed']) - 1)) * trait_graph_rect.width
                        y = trait_graph_rect.bottom - ((val - min_speed) / range_speed) * trait_graph_rect.height
                        points.append((x, y))
                    if len(points) > 1:
                        pygame.draw.lines(graph_surface, SAVE_COLOURS["speed"], False, points, 2)
                
                #draw vision line
                if self.history['avg_vision']:
                    points = []
                    for i, val in enumerate(self.history['avg_vision']):
                        x = trait_graph_rect.left + (i / (len(self.history['avg_vision']) - 1)) * trait_graph_rect.width
                        y = trait_graph_rect.bottom - ((val - min_vision) / range_vision) * trait_graph_rect.height
                        points.append((x, y))
                    if len(points) > 1:
                        pygame.draw.lines(graph_surface, SAVE_COLOURS["vision"], False, points, 2)
    
            #add titles
            title_font = pygame.font.Font(None, 36)
            
            pop_title = title_font.render("Population Over Time", True, SAVE_COLOURS["text"])
            graph_surface.blit(pop_title, (pop_graph_rect.centerx - pop_title.get_width()//2, 10))
            
            trait_title = title_font.render("Average Traits Over Time", True, SAVE_COLOURS["text"])
            graph_surface.blit(trait_title, (trait_graph_rect.centerx - trait_title.get_width()//2, pop_graph_rect.bottom + 10))
    
            #add legends
            legend_font = pygame.font.Font(None, 28)
            
            legend_y = pop_graph_rect.bottom + 10
            pygame.draw.rect(graph_surface, SAVE_COLOURS["creature"], (padding, legend_y, 20, 20))
            creature_label = legend_font.render("Creatures", True, SAVE_COLOURS["text"])
            graph_surface.blit(creature_label, (padding + 30, legend_y))
            
            pygame.draw.rect(graph_surface, SAVE_COLOURS["food"], (padding + 150, legend_y, 20, 20))
            food_label = legend_font.render("Food", True, SAVE_COLOURS["text"])
            graph_surface.blit(food_label, (padding + 180, legend_y))
            
            legend_y = trait_graph_rect.bottom + 10
            pygame.draw.rect(graph_surface, SAVE_COLOURS["size"], (padding, legend_y, 20, 20))
            size_label = legend_font.render("Size", True, SAVE_COLOURS["text"])
            graph_surface.blit(size_label, (padding + 30, legend_y))
            
            pygame.draw.rect(graph_surface, SAVE_COLOURS["speed"], (padding + 100, legend_y, 20, 20))
            speed_label = legend_font.render("Speed", True, SAVE_COLOURS["text"])
            graph_surface.blit(speed_label, (padding + 130, legend_y))
            
            pygame.draw.rect(graph_surface, SAVE_COLOURS["vision"], (padding + 200, legend_y, 20, 20))
            vision_label = legend_font.render("Vision", True, SAVE_COLOURS["text"])
            graph_surface.blit(vision_label, (padding + 230, legend_y))
    
            #add parameters
            params = self.get_params()
            params_text = [
                f"Simulation Parameters:",
                f"Initial Creatures: {params['initial_creatures']}  Max Creatures: {params['max_creatures']}  Repro Rate: {params['repro_rate']:.1f}%",
                f"Initial Food: {params['initial_food']}  Max Food: {params['max_food']}  Food Spawn Rate: {params['food_spawn_rate']:.1f}/s",
                f"Current State: Time={self.time_step/TARGET_FPS:.1f}s  Creatures={len(self.creatures)}  Food={len(self.foods)}",
                f"Current Traits: Size={sum(c.size for c in self.creatures)/len(self.creatures):.1f}  Speed={sum(c.speed for c in self.creatures)/len(self.creatures):.1f}  Vision={sum(c.vision for c in self.creatures)/len(self.creatures):.1f}"
            ]
            
            param_start_y = trait_graph_rect.bottom + 50
            param_font = pygame.font.Font(None, 26)
            
            for i, text in enumerate(params_text):
                text_surface = param_font.render(text, True, SAVE_COLOURS["text"])
                graph_surface.blit(text_surface, (padding, param_start_y + i*30))
    
            #save image
            pygame.image.save(graph_surface, filepath)
            return True
    
        except Exception as e:
            print(f"Error saving graph image: {e}")
            return False

def run_simulation(colour_scheme="default"):
    """main simulation loop"""
    global colours
    
    #set colour scheme
    if colour_scheme in COLOUR_SCHEMES:
        colours = COLOUR_SCHEMES[colour_scheme]
    else:
        colours = COLOUR_SCHEMES["default"]
    
    #initialize pygame
    if not pygame.get_init():
        pygame.init()
    
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Genetic Evolution Simulation")
    clock = pygame.time.Clock()
    
    simulation = GeneticEvolutionSim(screen)
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            result = simulation.handle_event(event)
            if result == "back":
                running = False
        
        simulation.update()
        simulation.draw()
        pygame.display.flip()
        clock.tick(TARGET_FPS)
    
    return True

if __name__ == "__main__":
    colour_scheme = sys.argv[1] if len(sys.argv) > 1 else "default"
    run_simulation(colour_scheme)