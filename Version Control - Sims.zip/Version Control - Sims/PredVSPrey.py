import pygame
import sys
import math
import random
import json
from datetime import datetime
import os


#constants
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
TARGET_FPS = 60

#colour schemes (must match main application)
COLOUR_SCHEMES = {
    "default": {
        "background": (64, 64, 64),
        "text": (255, 255, 255),
        "button": (30, 30, 30),
        "button_hover": (40, 40, 40),
        "border": (80, 80, 80),
        "border_hover": (100, 100, 100),
        "title": (255, 255, 255),
        "sim_bg": (200, 200, 200),
        "prey": (34, 139, 34),
        "predator": (220, 20, 60),
        "graph_bg": (255, 255, 255),
        "input_bg": (220, 220, 220),
        "input_text": (0, 0, 0),
        "input_active": (255, 255, 200)
    },
    "high_contrast": {
        "background": (0, 0, 0),
        "text": (255, 255, 255),
        "button": (0, 0, 0),
        "button_hover": (50, 50, 50),
        "border": (255, 255, 255),
        "border_hover": (255, 255, 0),
        "title": (255, 255, 0),
        "sim_bg": (50, 50, 50),
        "prey": (0, 255, 0),
        "predator": (255, 0, 0),
        "graph_bg": (0, 0, 0),
        "input_bg": (30, 30, 30),
        "input_text": (255, 255, 255),
        "input_active": (83, 83, 83)
    },
    "dark_blue": {
        "background": (0, 0, 50),
        "text": (200, 200, 255),
        "button": (0, 0, 80),
        "button_hover": (0, 0, 120),
        "border": (100, 100, 255),
        "border_hover": (150, 150, 255),
        "title": (200, 200, 255),
        "sim_bg": (0, 0, 70),
        "prey": (100, 255, 100),
        "predator": (255, 100, 100),
        "graph_bg": (0, 0, 30),
        "input_bg": (0, 0, 90),
        "input_text": (200, 200, 255),
        "input_active": (68, 85, 90)
    },
    "light_mode": {
        "background": (240, 240, 240),
        "text": (0, 0, 0),
        "button": (220, 220, 220),
        "button_hover": (200, 200, 200),
        "border": (100, 100, 100),
        "border_hover": (50, 50, 50),
        "title": (0, 0, 0),
        "sim_bg": (255, 255, 255),
        "prey": (0, 180, 0),
        "predator": (200, 0, 0),
        "graph_bg": (255, 255, 255),
        "input_bg": (255, 255, 255),
        "input_text": (0, 0, 0),
        "input_active": (255, 255, 180)
    }
}

colours = None

class Button:
    def __init__(self, x, y, width, height, text, font):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.hovered = False
        
    def draw(self, screen):
        colour = colours["button_hover"] if self.hovered else colours["button"]
        border_colour = colours["border_hover"] if self.hovered else colours["border"]
        
        pygame.draw.rect(screen, colour, self.rect, border_radius=15)
        pygame.draw.rect(screen, border_colour, self.rect, width=2, border_radius=15)
        
        text_surface = self.font.render(self.text, True, colours["text"])
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)
    
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                return True
        return False

class InputBox:
    def __init__(self, x, y, w, h, text='', description=''):
        self.rect = pygame.Rect(x, y, w, h)
        self.colour = colours["input_bg"]
        self.text = text
        self.default_text = text
        self.description = description
        self.txt_surface = pygame.font.Font(None, 24).render(text, True, colours["input_text"])
        self.active = False
        self.font = pygame.font.Font(None, 24)
        self.desc_font = pygame.font.Font(None, 20)
        
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = True
                self.colour = colours["input_active"]
                if self.text == self.default_text:
                    self.text = ''
            else:
                self.active = False
                self.colour = colours["input_bg"]
                if not self.text:
                    self.text = self.default_text
            
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    self.active = False
                    self.colour = colours["input_bg"]
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                self.txt_surface = self.font.render(self.text, True, colours["input_text"])
    
    def get_value(self):
        try:
            return float(self.text) if '.' in self.text else int(self.text)
        except ValueError:
            return 0
    
    def draw(self, screen):
        screen.blit(self.desc_font.render(self.description, True, colours["text"]), (self.rect.x, self.rect.y - 18))
        pygame.draw.rect(screen, self.colour, self.rect, 0, 5)
        pygame.draw.rect(screen, colours["border"], self.rect, 2, 5)
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

class Animal:
    def __init__(self, x, y, animal_type, params):
        self.x = x
        self.y = y
        self.type = animal_type
        self.size = 2 if animal_type == 'prey' else 3
        self.energy = 100
        self.age = 0
        self.is_dead = False
        self.params = params
        
        #movement parameters
        speed_param = params['prey_speed'] if animal_type == 'prey' else params['pred_speed']
        self.speed = random.uniform(speed_param * 0.8, speed_param * 1.2)
        self.direction = random.uniform(0, 2 * math.pi)
        self.detection_range = 80 if animal_type == 'prey' else 120
        
        #reproduction parameters
        self.reproduction_timer = 0
        self.reproduction_rate = params['prey_repro_rate'] if animal_type == 'prey' else params['pred_repro_rate']
        self.reproduction_energy_threshold = 70 if animal_type == 'prey' else 110
        self.reproduction_range = 60
        self.partner = None
        
        if animal_type == 'predator':
            self.time_since_last_meal = 0
            self.eat_cooldown = 0
            self.base_energy_loss = 0.15
            self.starvation_energy_loss = 0.35
            self.starvation_threshold = params['pred_starvation_time'] * TARGET_FPS
        else:
            self.grazing_rate = 0.12
    
    def move(self, nearby_animals, sim_rect):
        closest_target = None
        min_distance = float('inf')
        target_direction = None
        
        for other in nearby_animals:
            if other == self or other.is_dead:
                continue
                
            dx = other.x - self.x
            dy = other.y - self.y
            distance = math.sqrt(dx*dx + dy*dy)
            
            if distance > self.detection_range:
                continue
            
            if self.type == 'predator' and other.type == 'prey':
                if distance < min_distance:
                    min_distance = distance
                    closest_target = other
                    target_direction = math.atan2(dy, dx)
            
            elif self.type == 'prey':
                if other.type == 'predator':
                    if distance < min_distance:
                        min_distance = distance
                        closest_target = other
                        target_direction = math.atan2(-dy, -dx)
                elif (other.type == 'prey' and self.can_reproduce() and other.can_reproduce() 
                      and distance < self.reproduction_range and not self.partner):
                    self.partner = other
                    other.partner = self
        
        if closest_target:
            if (self.type == 'predator' and min_distance < self.size + closest_target.size + 8 
                and self.eat_cooldown <= 0):
                closest_target.is_dead = True
                self.energy = min(120, self.energy + 35)
                self.time_since_last_meal = 0
                self.eat_cooldown = 45
                
                if self.energy > 80 and random.random() < 0.15:
                    return [self.reproduce_from_feeding()]
            else:
                angle_diff = (target_direction - self.direction + math.pi) % (2 * math.pi) - math.pi
                self.direction += angle_diff * 0.12
        else:
            self.direction += random.uniform(-0.15, 0.15)
        
        self.direction %= 2 * math.pi
        
        new_x = self.x + math.cos(self.direction) * self.speed
        new_y = self.y + math.sin(self.direction) * self.speed
        
        if new_x <= sim_rect.left + self.size or new_x >= sim_rect.right - self.size:
            self.direction = math.pi - self.direction
            new_x = max(sim_rect.left + self.size, min(new_x, sim_rect.right - self.size))
            
        if new_y <= sim_rect.top + self.size or new_y >= sim_rect.bottom - self.size:
            self.direction = -self.direction
            new_y = max(sim_rect.top + self.size, min(new_y, sim_rect.bottom - self.size))
        
        self.x = new_x
        self.y = new_y
        
        self.age += 1
        self.reproduction_timer += 1
        
        if self.type == 'predator':
            self.time_since_last_meal += 1
            if self.eat_cooldown > 0:
                self.eat_cooldown -= 1
            
            energy_loss = self.base_energy_loss
            if self.time_since_last_meal > self.starvation_threshold:
                energy_loss += self.starvation_energy_loss
            
            self.energy -= energy_loss
            
            if self.energy <= 0:
                self.is_dead = True
        else:
            self.energy = min(120, self.energy + self.grazing_rate)
            
            if self.age > 1800 and random.random() < 0.001:
                self.is_dead = True
    
    def can_reproduce(self):
        return (self.energy > self.reproduction_energy_threshold and 
                self.age > 180 and 
                self.reproduction_timer > 300)
    
    def try_reproduce(self):
        if not self.can_reproduce():
            return []
        
        energy_factor = min(1.0, self.energy / 100.0)
        frame_probability = (self.reproduction_rate * energy_factor) / 100.0 / TARGET_FPS
        
        if random.random() < frame_probability:
            return self.reproduce()
        return []
    
    def reproduce(self):
        offspring = []
        
        if self.type == 'prey' and self.partner and self.partner.can_reproduce():
            babies = random.randint(3, 8)
            for _ in range(babies):
                angle = random.uniform(0, 2 * math.pi)
                distance = random.uniform(8, 20)
                x = self.x + math.cos(angle) * distance
                y = self.y + math.sin(angle) * distance
                offspring.append(Animal(x, y, 'prey', self.params))
            
            self.reproduction_timer = 0
            self.partner.reproduction_timer = 0
            self.energy -= 35
            self.partner.energy -= 35
            self.partner.partner = None
            self.partner = None
        
        elif self.type == 'predator':
            if self.energy > 100:
                babies = random.randint(2, 5)
                for _ in range(babies):
                    angle = random.uniform(0, 2 * math.pi)
                    distance = random.uniform(15, 30)
                    x = self.x + math.cos(angle) * distance
                    y = self.y + math.sin(angle) * distance
                    offspring.append(Animal(x, y, 'predator', self.params))
                
                self.reproduction_timer = 0
                self.energy -= 60
        
        return offspring
    
    def reproduce_from_feeding(self):
        if self.type == 'predator':
            angle = random.uniform(0, 2 * math.pi)
            distance = random.uniform(15, 30)
            x = self.x + math.cos(angle) * distance
            y = self.y + math.sin(angle) * distance
            self.energy -= 40
            return Animal(x, y, 'predator', self.params)
        return None

class Simulation:
    def __init__(self, screen):
        self.screen = screen
        self.font_title = pygame.font.Font(None, 36)
        self.font_ui = pygame.font.Font(None, 24)
        self.font_button = pygame.font.Font(None, 26)
        
        self.sim_rect = pygame.Rect(20, 80, 700, 570)
        self.animals = []
        self.population_history = {'prey': [], 'predator': [], 'time': []}
        self.running = False
        self.time_step = 0
        
        #control buttons
        self.buttons = {
            'start_pause': Button(740, 20, 100, 40, "START", self.font_button),
            'reset': Button(850, 20, 80, 40, "RESET", self.font_button),
            'download': Button(940, 20, 120, 40, "DOWNLOAD", self.font_button),
            'back': Button(1070, 20, 100, 40, "BACK", self.font_button)
        }
        
        self.input_boxes = [
            InputBox(740, 110, 100, 30, '60', 'Initial Prey'),
            InputBox(860, 110, 100, 30, '8', 'Initial Predators'),
            InputBox(740, 170, 100, 30, '1.5', 'Prey Speed'),
            InputBox(860, 170, 100, 30, '2.0', 'Predator Speed'),
            InputBox(740, 230, 100, 30, '1.8', 'Prey Repro Rate %'),
            InputBox(860, 230, 100, 30, '0.5', 'Pred Repro Rate %'),
            InputBox(980, 110, 100, 30, '1', 'Pred Starve Time (s)')
        ]
        
        self.init_simulation()
    
    def get_params(self):
        return {
            'initial_prey': self.input_boxes[0].get_value(),
            'initial_predators': self.input_boxes[1].get_value(),
            'prey_speed': self.input_boxes[2].get_value(),
            'pred_speed': self.input_boxes[3].get_value(),
            'prey_repro_rate': self.input_boxes[4].get_value(),
            'pred_repro_rate': self.input_boxes[5].get_value(),
            'pred_starvation_time': self.input_boxes[6].get_value()
        }
    
    def init_simulation(self):
        self.animals = []
        self.time_step = 0
        self.population_history = {'prey': [], 'predator': [], 'time': []}
        params = self.get_params()
        
        for _ in range(int(params['initial_prey'])):
            x = random.randint(self.sim_rect.left + 30, self.sim_rect.right - 30)
            y = random.randint(self.sim_rect.top + 30, self.sim_rect.bottom - 30)
            self.animals.append(Animal(x, y, 'prey', params))
            
        for _ in range(int(params['initial_predators'])):
            x = random.randint(self.sim_rect.left + 30, self.sim_rect.right - 30)
            y = random.randint(self.sim_rect.top + 30, self.sim_rect.bottom - 30)
            self.animals.append(Animal(x, y, 'predator', params))
    
    def handle_event(self, event):
        if event.type == pygame.QUIT:
            return 'back'
            
        for name, button in self.buttons.items():
            if button.handle_event(event):
                if name == 'start_pause':
                    self.running = not self.running
                    button.text = "PAUSE" if self.running else "START"
                elif name == 'reset':
                    self.init_simulation()
                    self.running = False
                    self.buttons['start_pause'].text = "START"
                elif name == 'download':
                    self.download_data()
                elif name == 'back':
                    return 'back'
        
        for box in self.input_boxes:
            box.handle_event(event)
    
    def update(self):
        if not self.running:
            return
            
        self.time_step += 1
        
        grid = {}
        for animal in self.animals:
            if not animal.is_dead:
                cell = (int(animal.x / 100), int(animal.y / 100))
                if cell not in grid:
                    grid[cell] = []
                grid[cell].append(animal)
        
        new_animals = []
        
        for animal in self.animals:
            if not animal.is_dead:
                cell = (int(animal.x / 100), int(animal.y / 100))
                nearby = []
                for dx in [-1, 0, 1]:
                    for dy in [-1, 0, 1]:
                        nearby_cell = (cell[0] + dx, cell[1] + dy)
                        if nearby_cell in grid:
                            nearby.extend(grid[nearby_cell])
                
                feeding_offspring = animal.move(nearby, self.sim_rect)
                if feeding_offspring:
                    new_animals.extend(feeding_offspring)
        
        for animal in self.animals:
            if not animal.is_dead:
                offspring = animal.try_reproduce()
                new_animals.extend(offspring)
        
        self.animals.extend(new_animals)
        self.animals = [a for a in self.animals if not a.is_dead]
        
        if self.time_step % 30 == 0:
            prey_count = sum(1 for a in self.animals if a.type == 'prey')
            predator_count = sum(1 for a in self.animals if a.type == 'predator')
            
            self.population_history['prey'].append(prey_count)
            self.population_history['predator'].append(predator_count)
            self.population_history['time'].append(self.time_step / TARGET_FPS)
            
            if len(self.population_history['time']) > 1000:
                for key in self.population_history:
                    self.population_history[key] = self.population_history[key][-1000:]
    
    def draw(self):
        self.screen.fill(colours["background"])
        
        #title and info
        title_text = self.font_title.render("Predator-Prey Simulation", True, colours["title"])
        self.screen.blit(title_text, (20, 20))
        
        status = "RUNNING" if self.running else "PAUSED"
        status_text = self.font_ui.render(f"Status: {status}", True, colours["text"])
        self.screen.blit(status_text, (20, 660))
        
        prey_count = sum(1 for a in self.animals if a.type == 'prey')
        pred_count = sum(1 for a in self.animals if a.type == 'predator')
        pop_text = self.font_ui.render(f"Prey: {prey_count} | Predators: {pred_count}", True, colours["text"])
        self.screen.blit(pop_text, (20, 685))
        
        time_text = self.font_ui.render(f"Time: {self.time_step / TARGET_FPS:.1f}s", True, colours["text"])
        self.screen.blit(time_text, (300, 660))
        
        #simulation area
        pygame.draw.rect(self.screen, colours["sim_bg"], self.sim_rect)
        pygame.draw.rect(self.screen, colours["border"], self.sim_rect, 2)
        
        #draw animals
        for animal in self.animals:
            if not animal.is_dead:
                x = int(max(self.sim_rect.left + animal.size, min(animal.x, self.sim_rect.right - animal.size)))
                y = int(max(self.sim_rect.top + animal.size, min(animal.y, self.sim_rect.bottom - animal.size)))
                
                energy_ratio = max(0.3, min(1.0, animal.energy / 100.0))
                if animal.type == 'prey':
                    colour = tuple(int(c * energy_ratio) for c in colours["prey"])
                else:
                    colour = tuple(int(c * energy_ratio) for c in colours["predator"])
                
                pygame.draw.circle(self.screen, colour, (x, y), animal.size)
        
        #ui elements
        for box in self.input_boxes:
            box.draw(self.screen)
        
        for button in self.buttons.values():
            button.draw(self.screen)
        
        self.draw_population_graph()
    
    def draw_population_graph(self):
        graph_rect = pygame.Rect(740, 300, 520, 280)
        pygame.draw.rect(self.screen, colours["graph_bg"], graph_rect)
        pygame.draw.rect(self.screen, colours["border"], graph_rect, 2)
        
        if len(self.population_history['time']) > 1:
            max_pop = max(max(self.population_history['prey']) if self.population_history['prey'] else [1], 
                         max(self.population_history['predator']) if self.population_history['predator'] else [1])
            max_pop = max(max_pop, 1)
            
            if len(self.population_history['prey']) > 1:
                points = []
                for i, pop in enumerate(self.population_history['prey']):
                    x = graph_rect.left + (i / max(1, len(self.population_history['prey']) - 1)) * graph_rect.width
                    y = graph_rect.bottom - (pop / max_pop) * graph_rect.height
                    points.append((x, y))
                if len(points) > 1:
                    pygame.draw.lines(self.screen, colours["prey"], False, points, 2)
            
            if len(self.population_history['predator']) > 1:
                points = []
                for i, pop in enumerate(self.population_history['predator']):
                    x = graph_rect.left + (i / max(1, len(self.population_history['predator']) - 1)) * graph_rect.width
                    y = graph_rect.bottom - (pop / max_pop) * graph_rect.height
                    points.append((x, y))
                if len(points) > 1:
                    pygame.draw.lines(self.screen, colours["predator"], False, points, 2)
        
        title = self.font_ui.render("Population Over Time", True, colours["text"])
        self.screen.blit(title, (graph_rect.left, graph_rect.top - 25))
        
        prey_legend = self.font_ui.render("Prey", True, colours["prey"])
        pred_legend = self.font_ui.render("Predators", True, colours["predator"])
        self.screen.blit(prey_legend, (graph_rect.right - 150, graph_rect.top - 25))
        self.screen.blit(pred_legend, (graph_rect.right - 80, graph_rect.top - 25))

    def download_data(self):
        """save simulation graph as an image file with consistent, readable colours"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"predator_prey_sim_{timestamp}.png"
        os.makedirs("simulation_data", exist_ok=True)
        filepath = os.path.join("simulation_data", filename)
    
        try:
            #fixed colour scheme for saved images (high contrast, readable)
            SAVE_COLOURS = {
                "bg": (255, 255, 255),        #white background
                "graph_bg": (240, 240, 240),  #light grey graph background
                "border": (100, 100, 100),    #dark grey border
                "grid": (220, 220, 220),      #light grey grid
                "text": (0, 0, 0),            #black text
                "prey": (0, 100, 0),          #dark green prey line
                "predator": (200, 0, 0),      #dark red predator line
                "legend_box": (200, 200, 200) #light grey legend boxes
            }
    
            #create surface with extra space for parameters
            graph_width = 1000
            graph_height = 600
            graph_surface = pygame.Surface((graph_width, graph_height))
            graph_surface.fill(SAVE_COLOURS["bg"])
    
            #layout parameters
            padding = 20
            title_spacing = 40
            graph_area_height = 450
    
            #draw population graph
            graph_rect = pygame.Rect(padding, title_spacing, graph_width - 2*padding, graph_area_height)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["graph_bg"], graph_rect)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["border"], graph_rect, 2)
    
            if len(self.population_history['time']) > 1:
                max_time = max(self.population_history['time'])
                max_pop = max(max(self.population_history['prey'] or [0]), 
                             max(self.population_history['predator'] or [0])) or 1
                
                #draw grid lines
                for i in range(5):
                    #horizontal (population) lines
                    y = graph_rect.bottom - i * graph_rect.height // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (graph_rect.left, y),
                                   (graph_rect.right, y), 1)
                    
                    #vertical (time) lines
                    x = graph_rect.left + i * graph_rect.width // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (x, graph_rect.top),
                                   (x, graph_rect.bottom), 1)
                
                #prey population line (dark green)
                if self.population_history['prey']:
                    points = []
                    for i in range(len(self.population_history['prey'])):
                        x = graph_rect.left + (self.population_history['time'][i]/max_time) * graph_rect.width
                        y = graph_rect.bottom - (self.population_history['prey'][i]/max_pop) * graph_rect.height
                        points.append((x, y))
                    pygame.draw.lines(graph_surface, SAVE_COLOURS["prey"], False, points, 3)
                
                #predator population line (dark red)
                if self.population_history['predator']:
                    points = []
                    for i in range(len(self.population_history['predator'])):
                        x = graph_rect.left + (self.population_history['time'][i]/max_time) * graph_rect.width
                        y = graph_rect.bottom - (self.population_history['predator'][i]/max_pop) * graph_rect.height
                        points.append((x, y))
                    pygame.draw.lines(graph_surface, SAVE_COLOURS["predator"], False, points, 3)
    
            #add title (positioned above the graph with proper spacing)
            title_font = pygame.font.Font(None, 36)
            title = title_font.render("Population Over Time", True, SAVE_COLOURS["text"])
            graph_surface.blit(title, (graph_rect.centerx - title.get_width()//2, 10))
            
            #legend (positioned below the graph)
            legend_y = graph_rect.bottom + 20
            legend_font = pygame.font.Font(None, 28)
            
            #prey legend
            pygame.draw.rect(graph_surface, SAVE_COLOURS["prey"], (padding, legend_y, 20, 20))
            prey_label = legend_font.render("Prey Population", True, SAVE_COLOURS["text"])
            graph_surface.blit(prey_label, (padding + 30, legend_y))
            
            #predator legend
            pygame.draw.rect(graph_surface, SAVE_COLOURS["predator"], (padding + 220, legend_y, 20, 20))
            pred_label = legend_font.render("Predator Population", True, SAVE_COLOURS["text"])
            graph_surface.blit(pred_label, (padding + 250, legend_y))
    
            #add parameters text (positioned below the legend)
            params = self.get_params()
            params_text = [
                f"Simulation Parameters:",
                f"Initial Prey: {params['initial_prey']}  Initial Predators: {params['initial_predators']}",
                f"Prey Speed: {params['prey_speed']:.1f}  Predator Speed: {params['pred_speed']:.1f}",
                f"Prey Repro Rate: {params['prey_repro_rate']:.1f}%  Pred Repro Rate: {params['pred_repro_rate']:.1f}%",
                f"Pred Starve Time: {params['pred_starvation_time']:.1f}s",
                f"Current State: Time={self.time_step/TARGET_FPS:.1f}s  Prey={sum(1 for a in self.animals if a.type == 'prey')}  Predators={sum(1 for a in self.animals if a.type == 'predator')}"
            ]
            
            param_start_y = legend_y + 40
            param_font = pygame.font.Font(None, 26)
            
            for i, text in enumerate(params_text):
                text_surface = param_font.render(text, True, SAVE_COLOURS["text"])
                graph_surface.blit(text_surface, (padding, param_start_y + i*30))
    
            #save the surface as png
            pygame.image.save(graph_surface, filepath)
            print(f"✅ graph image saved to {filepath}")
            return True
    
        except Exception as e:
            print(f"❌ error saving graph image: {e}")
            return False
        
def run_simulation(colour_scheme="default"):
    """main function to run the simulation with specified colour scheme"""
    global colours
    
    #set up colour scheme
    if colour_scheme in COLOUR_SCHEMES:
        colours = COLOUR_SCHEMES[colour_scheme]
    else:
        colours = COLOUR_SCHEMES["default"]
    
    #initialize pygame if not already initialized
    if not pygame.get_init():
        pygame.init()
    
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Predator-Prey Simulation")
    clock = pygame.time.Clock()
    
    simulation = Simulation(screen)
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            result = simulation.handle_event(event)
            if result == 'back':
                running = False
        
        simulation.update()
        simulation.draw()
        pygame.display.flip()
        clock.tick(TARGET_FPS)
    
    #clean return - don't quit pygame entirely
    return True

if __name__ == "__main__":
    #get colour scheme from command line if provided
    colour_scheme = sys.argv[1] if len(sys.argv) > 1 else "default"
    run_simulation(colour_scheme)