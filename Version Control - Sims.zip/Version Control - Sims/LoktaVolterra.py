import pygame
import sys
import math
import json
from datetime import datetime
import os

#screen dimensions
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
TARGET_FPS = 60

#colour schemes
COLOUR_SCHEMES = {
    "default": {
        "background": (64, 64, 64),
        "text": (255, 255, 255),
        "button": (30, 30, 30),
        "button_hover": (40, 40, 40),
        "border": (80, 80, 80),
        "border_hover": (100, 100, 100),
        "title": (255, 255, 255),
        "graph_bg": (255, 255, 255),
        "prey": (34, 139, 34),
        "predator": (220, 20, 60),
        "phase": (70, 130, 180),
        "input_bg": (220, 220, 220),
        "input_text": (0, 0, 0),
        "grid": (200, 200, 200),
        "input_highlight": (255, 255, 200)
    },
    "high_contrast": {
        "background": (0, 0, 0),
        "text": (255, 255, 255),
        "button": (0, 0, 0),
        "button_hover": (50, 50, 50),
        "border": (255, 255, 255),
        "border_hover": (255, 255, 0),
        "title": (255, 255, 0),
        "graph_bg": (0, 0, 0),
        "prey": (0, 255, 0),
        "predator": (255, 0, 0),
        "phase": (0, 255, 255),
        "input_bg": (30, 30, 30),
        "input_text": (255, 255, 255),
        "grid": (100, 100, 100),
        "input_highlight": (83, 83, 83)
    },
    "dark_blue": {
        "background": (0, 0, 50),
        "text": (200, 200, 255),
        "button": (0, 0, 80),
        "button_hover": (0, 0, 120),
        "border": (100, 100, 255),
        "border_hover": (150, 150, 255),
        "title": (200, 200, 255),
        "graph_bg": (0, 0, 30),
        "prey": (100, 255, 100),
        "predator": (255, 100, 100),
        "phase": (100, 200, 255),
        "input_bg": (0, 0, 90),
        "input_text": (200, 200, 255),
        "grid": (50, 50, 100),
        "input_highlight": (68, 85, 90)
    },
    "light_mode": {
        "background": (240, 240, 240),
        "text": (0, 0, 0),
        "button": (220, 220, 220),
        "button_hover": (200, 200, 200),
        "border": (100, 100, 100),
        "border_hover": (50, 50, 50),
        "title": (0, 0, 0),
        "graph_bg": (255, 255, 255),
        "prey": (0, 180, 0),
        "predator": (200, 0, 0),
        "phase": (70, 130, 180),
        "input_bg": (255, 255, 255),
        "input_text": (0, 0, 0),
        "grid": (220, 220, 220),
        "input_highlight": (255, 255, 180)
    }
}

colours = None

class Button:
    def __init__(self, x, y, width, height, text, font):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.font = font
        self.hovered = False
        
    def draw(self, screen):
        colour = colours["button_hover"] if self.hovered else colours["button"]
        border_colour = colours["border_hover"] if self.hovered else colours["border"]
        
        pygame.draw.rect(screen, colour, self.rect, border_radius=15)
        pygame.draw.rect(screen, border_colour, self.rect, width=2, border_radius=15)
        
        text_surface = self.font.render(self.text, True, colours["text"])
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)
    
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                return True
        return False

class InputBox:
    def __init__(self, x, y, w, h, text='', description='', colour_scheme=None):
        self.rect = pygame.Rect(x, y, w, h)
        self.colours = colour_scheme or colours
        self.colour = self.colours["input_bg"]
        self.text = text
        self.default_text = text
        self.description = description
        self.txt_surface = pygame.font.Font(None, 24).render(text, True, self.colours["input_text"])
        self.active = False
        self.font = pygame.font.Font(None, 24)
        self.desc_font = pygame.font.Font(None, 20)
        
    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = True
                self.colour = self.colours["input_highlight"]
                if self.text == self.default_text:
                    self.text = ''
            else:
                self.active = False
                self.colour = self.colours["input_bg"]
                if not self.text:
                    self.text = self.default_text
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    self.active = False
                    self.colour = self.colours["input_bg"]
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                self.txt_surface = self.font.render(self.text, True, self.colours["input_text"])
    
    def get_value(self):
        try:
            return float(self.text) if '.' in self.text else int(self.text)
        except ValueError:
            return 0
    
    def draw(self, screen):
        screen.blit(self.desc_font.render(self.description, True, self.colours["text"]), (self.rect.x, self.rect.y - 18))
        pygame.draw.rect(screen, self.colour, self.rect, 0, 5)
        pygame.draw.rect(screen, self.colours["border"], self.rect, 2, 5)
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

class LotkaVolterraSimulation:
    def __init__(self, screen):
        self.screen = screen
        self.font_title = pygame.font.Font(None, 36)
        self.font_ui = pygame.font.Font(None, 24)
        self.font_button = pygame.font.Font(None, 26)
        
        #graph dimensions
        graph_width = 500
        graph_height = 300
        
        #population graph position
        self.pop_graph_rect = pygame.Rect(100, 100, graph_width, graph_height)
        
        #phase portrait position
        self.phase_rect = pygame.Rect(SCREEN_WIDTH - graph_width - 100, 100, graph_width, graph_height)
        
        #control area
        control_start_y = 450
        param_start_y = 510
        
        self.running = False
        self.time = 0
        self.dt = 0.01
        
        #population data
        self.current_prey = 0
        self.current_predator = 0
        self.prey_data = []
        self.predator_data = []
        self.time_data = []
        
        #control buttons
        total_button_width = 100 + 10 + 80 + 10 + 120
        button_start_x = SCREEN_WIDTH//2 - total_button_width//2
        self.buttons = {
            'start_pause': Button(button_start_x, control_start_y, 100, 40, "START", self.font_button),
            'reset': Button(button_start_x + 110, control_start_y, 80, 40, "RESET", self.font_button),
            'download': Button(button_start_x + 200, control_start_y, 120, 40, "DOWNLOAD", self.font_button),
            'back': Button(20, 20, 80, 40, "BACK", self.font_button)
        }
        
        #parameters
        total_param_width = 120*2 + 20
        param_start_x = button_start_x + 400
        param_spacing = 60
        param_start_y = param_start_y - 50
        
        self.input_boxes = [
            InputBox(param_start_x, param_start_y, 120, 30, '100', 'Initial Prey (x)', colours),
            InputBox(param_start_x, param_start_y + param_spacing, 120, 30, '1.0', 'Prey Growth (α)', colours),
            InputBox(param_start_x, param_start_y + 2*param_spacing, 120, 30, '0.075', 'Pred Efficiency (δ)', colours),
            InputBox(param_start_x + 140, param_start_y, 120, 30, '20', 'Initial Pred (y)', colours),
            InputBox(param_start_x + 140, param_start_y + param_spacing, 120, 30, '0.1', 'Predation (β)', colours),
            InputBox(param_start_x + 140, param_start_y + 2*param_spacing, 120, 30, '1.5', 'Pred Death (γ)', colours),
            InputBox(param_start_x, param_start_y + 3*param_spacing, 260, 30, '50', 'Duration (seconds)', colours)
        ]
        
        self.reset_simulation()
    
    def get_params(self):
        return {
            'initial_prey': self.input_boxes[0].get_value(),
            'initial_predators': self.input_boxes[3].get_value(),
            'alpha': self.input_boxes[1].get_value(),
            'beta': self.input_boxes[4].get_value(),
            'delta': self.input_boxes[2].get_value(),
            'gamma': self.input_boxes[5].get_value(),
            'time_duration': self.input_boxes[6].get_value()
        }
    
    def reset_simulation(self):
        params = self.get_params()
        self.current_prey = params['initial_prey']
        self.current_predator = params['initial_predators']
        self.prey_data = [self.current_prey]
        self.predator_data = [self.current_predator]
        self.time_data = [0]
        self.time = 0
        self.running = False
        self.buttons['start_pause'].text = "START"
    
    def handle_event(self, event):
        if self.buttons['back'].handle_event(event):
            return "back"
            
        for name, button in self.buttons.items():
            if name != 'back' and button.handle_event(event):
                if name == 'start_pause':
                    self.running = not self.running
                    button.text = "PAUSE" if self.running else "START"
                elif name == 'reset':
                    self.reset_simulation()
                elif name == 'download':
                    self.download_data()
        
        for box in self.input_boxes:
            box.handle_event(event)
    
    def update(self):
        if not self.running:
            return
            
        params = self.get_params()
        
        #lotka-volterra equations
        alpha = params['alpha']
        beta = params['beta']
        delta = params['delta']
        gamma = params['gamma']
        
        dx_dt = alpha * self.current_prey - beta * self.current_prey * self.current_predator
        dy_dt = delta * self.current_prey * self.current_predator - gamma * self.current_predator
        
        self.current_prey += dx_dt * self.dt
        self.current_predator += dy_dt * self.dt
        
        self.current_prey = max(0, self.current_prey)
        self.current_predator = max(0, self.current_predator)
        
        self.time += self.dt
        
        if len(self.time_data) == 0 or self.time - self.time_data[-1] >= 0.1:
            self.prey_data.append(self.current_prey)
            self.predator_data.append(self.current_predator)
            self.time_data.append(self.time)
            
            if len(self.time_data) > 1000:
                self.prey_data = self.prey_data[-1000:]
                self.predator_data = self.predator_data[-1000:]
                self.time_data = self.time_data[-1000:]
    
    def draw(self):
        self.screen.fill(colours["background"])
        
        #title
        title_text = self.font_title.render("Lotka-Volterra Simulation", True, colours["title"])
        self.screen.blit(title_text, (SCREEN_WIDTH//2 - title_text.get_width()//2, 20))
        
        #status info
        status = "RUNNING" if self.running else "PAUSED"
        status_text = self.font_ui.render(f"Status: {status}", True, colours["text"])
        self.screen.blit(status_text, (20, SCREEN_HEIGHT - 40))
        
        pop_text = self.font_ui.render(
            f"Prey: {self.current_prey:.1f} | Predators: {self.current_predator:.1f}", 
            True, colours["text"]
        )
        self.screen.blit(pop_text, (20, SCREEN_HEIGHT - 70))
        
        time_text = self.font_ui.render(f"Time: {self.time:.1f}s", True, colours["text"])
        self.screen.blit(time_text, (20, SCREEN_HEIGHT - 100))
        
        #draw both graphs
        self.draw_population_graph()
        self.draw_phase_portrait()
        
        #draw controls
        for box in self.input_boxes:
            box.draw(self.screen)
        
        for button in self.buttons.values():
            button.draw(self.screen)
    
    def draw_population_graph(self):
        #graph background
        pygame.draw.rect(self.screen, colours["graph_bg"], self.pop_graph_rect)
        pygame.draw.rect(self.screen, colours["border"], self.pop_graph_rect, 2)
        
        if len(self.time_data) > 1:
            max_pop = max(max(self.prey_data), max(self.predator_data), 1)
            
            #grid lines
            for i in range(5):
                y = self.pop_graph_rect.top + i * self.pop_graph_rect.height // 4
                pygame.draw.line(self.screen, colours["grid"], 
                               (self.pop_graph_rect.left, y),
                               (self.pop_graph_rect.right, y), 1)
            
            #prey population line
            if len(self.prey_data) > 1:
                points = []
                for i in range(len(self.prey_data)):
                    x = self.pop_graph_rect.left + (self.time_data[i]/self.time_data[-1]) * self.pop_graph_rect.width
                    y = self.pop_graph_rect.bottom - (self.prey_data[i]/max_pop) * self.pop_graph_rect.height
                    points.append((x, y))
                pygame.draw.lines(self.screen, colours["prey"], False, points, 2)
            
            #predator population line
            if len(self.predator_data) > 1:
                points = []
                for i in range(len(self.predator_data)):
                    x = self.pop_graph_rect.left + (self.time_data[i]/self.time_data[-1]) * self.pop_graph_rect.width
                    y = self.pop_graph_rect.bottom - (self.predator_data[i]/max_pop) * self.pop_graph_rect.height
                    points.append((x, y))
                pygame.draw.lines(self.screen, colours["predator"], False, points, 2)
        
        #graph title
        title = self.font_ui.render("Population Over Time", True, colours["text"])
        self.screen.blit(title, (self.pop_graph_rect.centerx - title.get_width()//2, 
                               self.pop_graph_rect.top - 25))
        
        #legend
        pygame.draw.rect(self.screen, colours["prey"], (self.pop_graph_rect.left + 10, self.pop_graph_rect.top + 320, 15, 15))
        prey_label = self.font_ui.render("Prey", True, colours["prey"])
        self.screen.blit(prey_label, (self.pop_graph_rect.left + 30, self.pop_graph_rect.top + 320))
        
        pygame.draw.rect(self.screen, colours["predator"], (self.pop_graph_rect.left + 100, self.pop_graph_rect.top + 320, 15, 15))
        pred_label = self.font_ui.render("Predators", True, colours["predator"])
        self.screen.blit(pred_label, (self.pop_graph_rect.left + 120, self.pop_graph_rect.top + 320))
    
    def draw_phase_portrait(self):
        #graph background
        pygame.draw.rect(self.screen, colours["graph_bg"], self.phase_rect)
        pygame.draw.rect(self.screen, colours["border"], self.phase_rect, 2)
        
        if len(self.prey_data) > 1:
            max_prey = max(self.prey_data) or 1
            max_pred = max(self.predator_data) or 1
            
            #draw axes with padding
            axis_padding = 30
            axis_start_x = self.phase_rect.left + axis_padding
            axis_end_x = self.phase_rect.right - 10
            axis_start_y = self.phase_rect.top + 10
            axis_end_y = self.phase_rect.bottom - axis_padding
            
            pygame.draw.line(
                self.screen, colours["text"],
                (axis_start_x, axis_end_y),
                (axis_end_x, axis_end_y),
                2
            )
            pygame.draw.line(
                self.screen, colours["text"],
                (axis_start_x, axis_start_y),
                (axis_start_x, axis_end_y),
                2
            )
            
            #draw phase curve
            points = []
            for i in range(0, len(self.prey_data), max(1, len(self.prey_data)//200)):
                x = axis_start_x + (self.prey_data[i]/max_prey) * (axis_end_x - axis_start_x)
                y = axis_end_y - (self.predator_data[i]/max_pred) * (axis_end_y - axis_start_y)
                points.append((x, y))
            
            if len(points) > 1:
                pygame.draw.lines(self.screen, colours["phase"], False, points, 2)
            
            #current position indicator
            if len(self.prey_data) > 0:
                current_x = axis_start_x + (self.current_prey/max_prey) * (axis_end_x - axis_start_x)
                current_y = axis_end_y - (self.current_predator/max_pred) * (axis_end_y - axis_start_y)
                pygame.draw.circle(self.screen, colours["predator"], (int(current_x), int(current_y)), 5)
        
        #graph title
        title = self.font_ui.render("Phase Portrait", True, colours["text"])
        self.screen.blit(title, (self.phase_rect.centerx - title.get_width()//2, 
                               self.phase_rect.top - 25))
    
    def download_data(self):
        """save simulation graph as an image file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"lotka_volterra_sim_{timestamp}.png"
        os.makedirs("simulation_data", exist_ok=True)
        filepath = os.path.join("simulation_data", filename)
    
        try:
            #fixed colour scheme for saved images
            SAVE_COLOURS = {
                "bg": (255, 255, 255),
                "graph_bg": (240, 240, 240),
                "border": (100, 100, 100),
                "grid": (220, 220, 220),
                "text": (0, 0, 0),
                "prey": (0, 100, 0),
                "predator": (200, 0, 0),
                "phase": (0, 0, 150),
                "legend_box": (200, 200, 200)
            }
    
            #create surface with extra space for parameters
            graph_width = 1000
            graph_height = 750
            graph_surface = pygame.Surface((graph_width, graph_height))
            graph_surface.fill(SAVE_COLOURS["bg"])
    
            #layout parameters
            padding = 20
            title_spacing = 40
            graph_area_height = 550
    
            #draw population graph
            pop_graph_rect = pygame.Rect(padding, title_spacing, 450, graph_area_height - title_spacing)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["graph_bg"], pop_graph_rect)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["border"], pop_graph_rect, 2)
    
            if len(self.time_data) > 1:
                max_pop = max(max(self.prey_data), max(self.predator_data), 1)
                
                #grid lines
                for i in range(5):
                    y = pop_graph_rect.top + i * pop_graph_rect.height // 4
                    pygame.draw.line(graph_surface, SAVE_COLOURS["grid"], 
                                   (pop_graph_rect.left, y),
                                   (pop_graph_rect.right, y), 1)
                
                #prey population line
                if len(self.prey_data) > 1:
                    points = []
                    for i in range(len(self.prey_data)):
                        x = pop_graph_rect.left + (self.time_data[i]/self.time_data[-1]) * pop_graph_rect.width
                        y = pop_graph_rect.bottom - (self.prey_data[i]/max_pop) * pop_graph_rect.height
                        points.append((x, y))
                    pygame.draw.lines(graph_surface, SAVE_COLOURS["prey"], False, points, 3)
                
                #predator population line
                if len(self.predator_data) > 1:
                    points = []
                    for i in range(len(self.predator_data)):
                        x = pop_graph_rect.left + (self.time_data[i]/self.time_data[-1]) * pop_graph_rect.width
                        y = pop_graph_rect.bottom - (self.predator_data[i]/max_pop) * pop_graph_rect.height
                        points.append((x, y))
                    pygame.draw.lines(graph_surface, SAVE_COLOURS["predator"], False, points, 3)
    
            #draw phase portrait
            phase_rect = pygame.Rect(graph_width - padding - 450, title_spacing, 450, graph_area_height - title_spacing)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["graph_bg"], phase_rect)
            pygame.draw.rect(graph_surface, SAVE_COLOURS["border"], phase_rect, 2)
    
            if len(self.prey_data) > 1:
                max_prey = max(self.prey_data) or 1
                max_pred = max(self.predator_data) or 1
                
                #draw axes with padding
                axis_padding = 30
                axis_start_x = phase_rect.left + axis_padding
                axis_end_x = phase_rect.right - 10
                axis_start_y = phase_rect.top + 10
                axis_end_y = phase_rect.bottom - axis_padding
                
                pygame.draw.line(
                    graph_surface, SAVE_COLOURS["text"],
                    (axis_start_x, axis_end_y),
                    (axis_end_x, axis_end_y),
                    2
                )
                pygame.draw.line(
                    graph_surface, SAVE_COLOURS["text"],
                    (axis_start_x, axis_start_y),
                    (axis_start_x, axis_end_y),
                    2
                )
                
                #draw phase curve
                points = []
                for i in range(0, len(self.prey_data), max(1, len(self.prey_data)//200)):
                    x = axis_start_x + (self.prey_data[i]/max_prey) * (axis_end_x - axis_start_x)
                    y = axis_end_y - (self.predator_data[i]/max_pred) * (axis_end_y - axis_start_y)
                    points.append((x, y))
                
                if len(points) > 1:
                    pygame.draw.lines(graph_surface, SAVE_COLOURS["phase"], False, points, 2)
    
            #add titles
            title_font = pygame.font.Font(None, 36)
            
            #population graph title
            pop_title = title_font.render("Population Over Time", True, SAVE_COLOURS["text"])
            graph_surface.blit(pop_title, (pop_graph_rect.centerx - pop_title.get_width()//2, 10))
            
            #phase portrait title
            phase_title = title_font.render("Phase Portrait", True, SAVE_COLOURS["text"])
            graph_surface.blit(phase_title, (phase_rect.centerx - phase_title.get_width()//2, 10))
            
            #legend
            legend_y = graph_area_height + 15
            legend_font = pygame.font.Font(None, 28)
            
            #prey legend
            pygame.draw.rect(graph_surface, SAVE_COLOURS["prey"], (padding, legend_y, 20, 20))
            prey_label = legend_font.render("Prey Population", True, SAVE_COLOURS["text"])
            graph_surface.blit(prey_label, (padding + 30, legend_y))
            
            #predator legend
            pygame.draw.rect(graph_surface, SAVE_COLOURS["predator"], (padding + 220, legend_y, 20, 20))
            pred_label = legend_font.render("Predator Population", True, SAVE_COLOURS["text"])
            graph_surface.blit(pred_label, (padding + 250, legend_y))
    
            #add parameters text
            params = self.get_params()
            params_text = [
                f"Model Parameters: α={params['alpha']:.3f}  β={params['beta']:.3f}  δ={params['delta']:.3f}  γ={params['gamma']:.3f}",
                f"Initial Conditions: Prey={params['initial_prey']}  Predators={params['initial_predators']}",
                f"Current State: Time={self.time:.1f}s  Prey={self.current_prey:.1f}  Predators={self.current_predator:.1f}"
            ]
            
            param_start_y = legend_y + 40
            param_font = pygame.font.Font(None, 26)
            
            for i, text in enumerate(params_text):
                text_surface = param_font.render(text, True, SAVE_COLOURS["text"])
                graph_surface.blit(text_surface, (padding, param_start_y + i*30))
    
            #save the surface as png
            pygame.image.save(graph_surface, filepath)
            return True
    
        except Exception as e:
            print(f"Error saving graph image: {e}")
            return False

def run_simulation(colour_scheme="default"):
    """main function to run the simulation"""
    global colours
    
    #set up colour scheme
    if colour_scheme in COLOUR_SCHEMES:
        colours = COLOUR_SCHEMES[colour_scheme]
    else:
        colours = COLOUR_SCHEMES["default"]
    
    #initialize pygame if not already initialized
    if not pygame.get_init():
        pygame.init()
    
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Lotka-Volterra Simulation")
    clock = pygame.time.Clock()
    
    simulation = LotkaVolterraSimulation(screen)
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            result = simulation.handle_event(event)
            if result == "back":
                running = False
        
        simulation.update()
        simulation.draw()
        pygame.display.flip()
        clock.tick(TARGET_FPS)
    
    return True

if __name__ == "__main__":
    colour_scheme = sys.argv[1] if len(sys.argv) > 1 else "default"
    run_simulation(colour_scheme)